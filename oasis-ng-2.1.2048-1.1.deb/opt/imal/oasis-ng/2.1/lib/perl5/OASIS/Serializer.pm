package OASIS::Serializer;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id: Serializer.pm 3109 2007-08-14 13:21:24Z tsout+schlittermann $
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Serializer.pm $

use 5.8.0;
our $VERSION = (split " ", q$Rev: 3109 $)[1];

use strict;
use warnings;
use Carp;
use if $ENV{DEBUG} => "Smart::Comments";

use OASIS::Logger;

sub serialize {
   my ($self, $data) = @_;
   $self->{serialize}->($data);
}

sub write {
   my ($self, $argv) = @_;

   ### assert: $argv->{stream}
   ### assert: $argv->{data}

   print { $argv->{stream} } $self->serialize($argv->{data});
}

sub deserialize {
   my ($self, $data) = @_;
   return $self->{deserialize}->($data);
}

sub read {
   my ($self, $argv) = @_;

   ### assert: $argv->{stream}
   ### assert: $argv->{length}

   debug("expect @{[$argv->{length}]} bytes");

   my $data        = "";
   my $read_so_far = 0;
   my $left        = $argv->{length};
   my $read;
   while ($left and $read = read($argv->{stream}, $data, $left, $read_so_far))
   {
      $read_so_far += $read;
      $left -= $read;
   }

   croak "short read: $!" if not defined $read;

   my $response_data =  eval { $self->deserialize($data) };
   if( $@ ){
      die "deserialisation error $@ with data: ".$data;
   }
   use Data::Dumper;
   debug("revieved mesage".Dumper($response_data));
   return $response_data;
}

sub name { shift->{name} }

sub new      { goto &ABSTRACT }
sub ABSTRACT { croak "abstract placeholder in " . __PACKAGE__ }

1;
__END__

=head1 NAME

serializer -- base class for all serializers

=head1 SYNOPSIS

   use serializer;
   my $serializer = new serializer;

   $serialized = $serializer->serialize(\%data);
   $hashref = $serializer->deserialize($serialized);

   $serializer->write({stream => \*STDOUT, data => \%data});
   $hashref = $serializer->read({stream => \*STDIN, length => 211});

   print "Using serializer: " . $serializer->{name};


=head1 DESCRIPTION

This class is some common base for all serializer.
The subclasses have to provide a constructor C<new> which sets
some attributes, e.g.:

   name           => "storable $Storable::VERSION",
   serializer     => \&Storable::nfreeze,
   deserializer   => \&Storable::thaw

After this the C<serialize>, C<deserialize>, C<read>, C<write>
and C<name> methods are implented, but may be overriden in some
subclasses.

=head1 CONSTRUCTOR

=over

=item new(Z<>)

Currently not implented. Should be implemented by the subclasses.

=back

=head1 METHODS

=over

=item serialize(I<data>)

Returns the serialized data.  I<data> needs to be a reference or a
simple scalar.

=item write({stream => I<stream>, data => I<data>})

Writes the serialized data to the stream specified.  Returns the B<true>
if succesfull, B<false> otherwise.

=item deserialize(I<data>)

"Thaws" the serialized data and returns a hash ref to the new structure;

=item read({stream => I<stream>, length => I<length>})

Read I<length> bytes from the stream and reconstruct the serialized
data.  If I<length> is not defined the deserializer has to do its best
to find the end of the data.  This may not succeed always.

=item name(Z<>)

Returns the name of the serializer.

=back

=head1 SEE ALSO

L<message>, L<message::request>, L<message::response>, L<serializer::storable>

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm:
