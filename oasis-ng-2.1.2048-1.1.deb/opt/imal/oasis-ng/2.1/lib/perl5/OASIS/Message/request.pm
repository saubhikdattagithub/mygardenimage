package OASIS::Message::request;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id: /local/sapsi/branch/ng/oasis/scratch/message/request.pm 10 2007-03-03T07:57:08.315076Z heiko  $
# $URL: /local/sapsi/branch/ng/oasis/scratch/message/request.pm $

use 5.8.0;
our $VERSION = (split " ", q$Rev: 3065 $)[1];

use strict;
use warnings;
use Carp;
use base qw(OASIS::Message);
use if $ENV{DEBUG} => "Smart::Comments";
use Data::Dumper;
{
   package REQUEST;
   use Class::Struct REQUEST => { sid       => '$',
                                  method    => '$',
                                  argv      => '@',
                                  wantarray => '$',
   };
   sub TO_JSON {
      my $self = shift;
      return {
         sid => $self->sid,
         method => $self->method,
         argv   => $self->argv,
         wantarray => $self->wantarray,
      };
   }

   1;
}
sub new {
   my ($class, $argv) = @_;
   $class = ref $class if ref $class;
   my $self;

   if (my $fh = $argv->{stream}) {
      $self = $class->SUPER::new($argv);
      $self->{body} = REQUEST->new(%{ $self->body } ) unless ref $self->body eq 'REQUEST';
      return $self;
   }

   # autodetect the context if not supplied
   $argv->{wantarray} = (caller 0)[5] if not exists $argv->{wantarray};

   # create the REQUEST struct and cleanup the %$argv, then
   # we can pass the reset to our BASE class
   my $r = new REQUEST %$argv;
   delete @{$argv}{ map { s/REQUEST::// && $_ } keys %$r };

   $self = $class->SUPER::new($argv);
   $self->{body} = $r;
   return $self;

}

1;
__END__

=head1 NAME

message::request -- OASIS message request

=head1 SYNOPSIS

   use message::request;

   $request = new message::request({
      sid        => $session_id,
      method     => $methodname,
      argv       => \@arguments,                # optional
      wantarray  => $context,                   # optional
   });

   $request = new message::request({
      stream     => \*STDIN
   });

   print $request->body->method();

=head1 DESCRIPTION

The "message::request" is basically a "message".  So all methods
of L<message> are available.

=head1 CONSTRUCTOR

=over

=item new { I<ARGS> }

Creates a new request.  The constructor takes a hash reference to the
following key/value pairs: B<method> is the name of the method to call.
It is the function call and some indirect objects (?), for instance
something like this:

   my $request = new message::request({
      method => "use demo"
   });

The B<argv> gets a reference to the argument vector as it should be
passed to the B<method>.  B<wantarray> is I<true> or I<false>, depending
on the context.  Normally it is autodetected.

Under some special circumstances you might want to pass a reference to 
your own B<serializer>.  This needs to be a subclass of L<serializer>.

=back

=head1 METHODS

There are accessor to the elements of the request.

=head1 SEE ALSO

L<message>, L<serializer>

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm:
