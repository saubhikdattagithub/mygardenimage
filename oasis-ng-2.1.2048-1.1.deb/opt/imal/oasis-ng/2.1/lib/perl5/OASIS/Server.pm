# © 2007 Heiko Schlittermann <hs@schlittermann.de>
#        Marcus Obst <mobst@schlittermann.de>
#
# $Id$
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Server.pm $

package OASIS::Server;

use 5.8.0;

use Carp;
use strict;
use warnings;
use IO::Socket;
use IO::Select;
use IO::File;
use IO::Pipe;
use IO::Socket::SSL 1.06;

use POSIX ":sys_wait_h";

use OASIS::Logger;
use OASIS::Scoreboard;

use if $ENV{DEBUG} => "Smart::Comments";

my %Servers;    # all our running server objects
my %h_processes; # maintain a list of child processes
$SIG{CHLD} = sub { $Servers{$_}->sig_chld(@_) for keys %Servers };

# Achtung, die muessen dann unten fuer die Kinder auch wieder
# zurueckgesetzt werden! (.hs 2007-08-22)
#$SIG{USR1} = sub { $Servers{$_}->sig_usr1(@_) for keys %Servers };
#$SIG{USR2} = sub { $Servers{$_}->sig_usr2(@_) for keys %Servers };

sub new {
   my $self = bless {}, ref $_[0] ? ref shift : shift;
   my $argv = shift;

   # Ja, wir könnten auch einfach
   # $self = $argv schreiben, aber das dokumentiert sich nicht so gut.
   # Noch besser wäre es, wir würden sowas wie restricted Hashs nehmen,
   # damit wir nicht einfach mal neue Variablen erfinden oder uns
   # verschreiben.

   $Servers{$self} = $self;                # track running servers here
   $self->{_pid_check_conf} = {
      max_runtime => 84600 * 2,
      check_cycle => 10,
   };
   $self->{conf} = delete $argv->{conf};
   $self->{max_workers} = delete $argv->{max_workers};    # not used currently
   $self->{port}
      = exists $argv->{port}
      ? delete $argv->{port}
      : $self->{conf}->get("server:port");

   # now all argv elements should be deleted
   croak qq{unknown parameters: @{[join ", ", keys %$argv]}} if %$argv;
   croak qq{Port is not defined!} if not defined $self->{port};

   return undef unless $self->_bind();    # bind port, set $self->{port}

   notice("created new server object, listening on port $self->{port}");
   debug("config files: @{[$self->{conf}->files()]}");

   return $self;
}

sub DESTROY { delete $Servers{ $_[0] } }

sub register_protocol {
   my ($self, $service) = @_;
   push @{ $self->{willing} }, $service;
}

sub socket { return $_[0]->{server} }

sub _bind {
   my $self = shift;
   my %ListeParameter;
   if( my $listen_address = $self->{conf}->get('server:listen_address') ){
      if( $listen_address eq '*' ){
         $listen_address = '0.0.0.0'
      }
      if( $listen_address =~ /\./ ){
         $ListeParameter{LocalAddr} = $listen_address;
      }else{
         $ListeParameter{LocalHost} = $listen_address;
      }

   }

   $self->{server} =
      IO::Socket::INET->new(Listen    => SOMAXCONN,
                            LocalPort => $self->{port},
                            ReuseAddr => 1,
                            %ListeParameter,
      ) or die "Can't create listener on $self->{port}: $!\n";

   $self->{port} ||= $self->{server}->sockport();
   return 1;
}

# ___Prefork___ ist etwas komplizierter.  Nachdem wir uns an den Port gebunden
# haben, forken wir einfach eine Sack voll Clients (Worker).
#
# Der Vater kann sich dann an dieser Stelle zur Ruhe legen und muss nur noch
# nachschauen, ob immer genügend Worker auf Vorrat vorhanden sind.
#
# Die Clients hingegen legen sich alle mit eine accept() auf die Lauer, wer
# zuerst kommt, malt zuerst.
#
# ACHTUNG: Im Sourcecode von Net::Server ist vermerkt, dass parallele
# accepts() auf den gleichen Socket nicht gut funktionieren und man deshalb
# serialisieren muss?!¹.
#
# Dabei wird ungefähr wie folgt vorgegangen:  Bevor jeder Client den accept()
# startet, schaut er erstmal mit select() nach, ob überhaupt etwas zu tun ist.
# Wenn ja, dann ist jetzt der Moment für Serialisierung.  Alle Clients
# versuchen sich nun exclusiv für das accept() anzumelden.  Hier gibt es
# mehrer Möglichkeiten z.B Semaphore (shared memory), flock, oder pipes.
#
# (Da flock sowohl unter Windows als auch Unix funktioniert, sollte dies die
# bevorzugte Methode sein.)
#
# Wer den Lock bekommt, darf dann den accept() ausführen.  Anschließend geht
# es weiter wie gewohnt!
#
# ¹ multiple accepts() auf den gleichen Socket funktionieren nur auf
#   BSD-Unixen und ab Solaris 2.6, alle anderen SysV-Unix könne dies nicht.
#
#   Unter alten Unix-Varianten (auch Linux bis 2.2.x) gibt es zusätzlich noch
#   das Problem der ,,thundering herd''.  Alle mit accept() blockierenden
#   Prozesse werden vom Kernel in die gleich wait_queue gelegt und im Falle
#   einer neuen Verbindung auch alle aufgeweckt.  Am Ende bekommt aber nur
#   einer die Verbindung und alle anderen dürfen sich wieder schlafen legen.
#

# max_workers      von new()   2
# min_workers      von new()   5
# living_workers      accept() + "busy" (scalar keys $self->{workers})
# busy_workers

sub run {
   my $self = shift;
   my $i_count = 0;

   while (1) {
      debug("accepting client connections");
      $self->{client} = $self->{server}->accept();
      next if not $self->{client};

      # just simple on demand fork for now!
      my $i_spawn_time = time();
      my $pid = fork();
      if (not defined $pid) {
         warn "Cannot fork worker process: $!";
         $self->{client}->close();
         next;
      }

      $i_count += 1;
      if ($pid == 0) {    # --- child/worker
                          # eventuell auch mit USR1 / USR2
         $SIG{CHLD} = "DEFAULT";
         undef @OASIS::Tools::CLEAN_FILES;
         #we dont care whath happening in there but we HAVE to exit after it
         eval{
             $self->{server}->close();
             $self->_run_worker();
             $self->{client}->close() if $self->{client}->connected();
         };
         if( my $error = $@ ){
            eval{
               debug( Carp::longmess( $error ));
            }
         }
         exit;
      }

      # --- parent
      $h_processes{$pid} = $i_spawn_time; # record spawn time of each child process
      if ($i_count >= $self->{_pid_check_conf}{check_cycle}) { # check and kill very old child processes every n-th request
         $i_count = 0;
         my $i_now = time();
         my @a_pids_to_kill = grep{$h_processes{$_} && ($i_now - $h_processes{$_})>=$self->{_pid_check_conf}{max_runtime}} keys %h_processes;
         if (scalar(@a_pids_to_kill)) {
            kill 15, @a_pids_to_kill; # SIGTERM first to kill child processes older than 2-day
            sleep(2);
            for my $i_pid (@a_pids_to_kill) {
               if (kill(0, $i_pid)) { # check if the child process is still alive
                  kill 9, $i_pid;     # SIGKILL as last resort.
               }
               delete $h_processes{$i_pid}; # we send SIGKILL or it was not running anymore, remove PID
            }
         }
      }
      debug("new on-demand worker with pid = $pid forked");
      $self->{client}->close();    # close newly created client socket
   }

}

sub _run_worker {
   my $self = shift;

   debug("accepting client connection from "
         . join(":", $self->{client}->peerhost(), $self->{client}->peerport())
   );

   #
   # Read first line from client.  Then put it in to all our
   # registerd protocol services and stop if the first one
   # aceppted/processed it.
   #
   my $first_line = $self->{client}->getline();

   if (not defined $first_line) {
      debug("worker finished (empty first line)");
      return;
   }

   $first_line =~ s/\s*$//;

   foreach my $service (@{ $self->{willing} }) {
      croak "No SERVE methode in $service"
         if not defined &{ ref($service) . "::serve" };

      last if $service->serve($self->{client}, $first_line);
   }

   debug("worker finished");
}

# Es kann auch passieren, daß uns SIGCHLD gesandt wird, obwohl wir nichts
# dafür können: Unix::Syslog z.B. macht sowas (Threading?)
#
# NOTE: Unter win32 scheinen wir das SIGCHLD nicht zu bekommen, wenn dem
# wirklich so ist, dann müssen wir diesen Signalhandler einfach ab und zu mal
# aus dem Hauptprozess aufrufen
#
sub sig_chld {
   my $self = shift;

   debug("Got signal CHLD");
   while ((my $pid = waitpid(-1, WNOHANG)) > 0) {
      delete($h_processes{$pid}); # remove child from list when exit signal is captured
      debug("child with pid $pid exited");
   }
}

1;

__END__

=head1 NAME

server -- generic fork and preforkable server class

=head1 SYNOPSIS

   use server;

   my $s = server->new({port => 4321 });

   $proxy = new Proxy();
   $oasis = new Oasis();

   $s->register_protocol($proxy);
   $s->register_protocol($oasis);

   $s->run();

=head1 DESCRIPTION

Generic server class which implements traditional unix on demand forking and 
advanced apache-like preforking.

=head1 METHODS

=over

=item new

If the B<port> is 0, the server binds to B<some> port.

=item register_protocol(I<Object>)

The I<Object> needs to implement an I<Object>->serve() method.
Just after TCP-connect the the C<serve()> methods of the registered
objects are called in order until the first one is willing to handle the
connection.  The C<serve>() method is called:

   $object->serve(SOCKET, FIRST-LINE)

We expect a true return value if the connection is/was successful
handled, otherwise some false value.

=item run( )

Starts the real work (creating workers etc.)

=item socket( )

Return the socket structure (L<IO::Socket::INET>). If you need the local
part:

   $local_port = $server->socket()->sockport();

=back

=head1 SIGNALS

This class sets the following signal handlers: B<CHLD>.
These signals are set to there default behaviour before
executing any code from the client.

=head1 SEE ALSO

Inspiration by I<Net::Server>

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

Marcus Obst <mobst@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm:
