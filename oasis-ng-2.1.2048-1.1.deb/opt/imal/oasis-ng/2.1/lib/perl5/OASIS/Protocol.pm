package OASIS::Protocol;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
#	 Marcus Obst <mobst@schlittermann.de>
#
# $Id: Protocol.pm 3099 2007-07-06 08:39:47Z tsout+schlittermann $
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Protocol.pm $
#
# This is just some abstract base class for the protocoll classes to
# have some template for own protocol implementations.

use 5.8.0;

use Carp;
use strict;
use warnings;

sub new      { goto &ABSTRACT }
sub set_conf { goto &ABSTRACT }
sub serve    { goto &ABSTRACT }

sub ABSTRACT { croak "abstract placeholder on " . __PACKAGE__ }

1;

__END__

=head1 NAME

OASIS::Protocol -- Oasis Protocol abstract base class

=head1 SYNOPSIS

   package OASIS::Protocol::xyz;
   use OASIS::Protocol;

   sub new { ... }

=head1 DESCRIPTION

This package is just an abstract base for the real protocol classes to
define an interface.

=head1 METHODS

=over

=item CONSTRUCTOR new({ conf => I<OASIS::Config object> })

The constructor does nothing special, but it expects a reference to a
OASIS::Config object.

=item serve(I<$socket>, I<$first_line>)

The first line should contain the information we need to decide if we're
willing to process this request. If we do not recognize the
I<$first_line>, we return 0, otherwise we're expected to handle the
request over the passed client I<$socket>.

=back

=head1 SEE ALSO

OASIS::Server, OASIS::Protocol::oasis3
OASIS::Protocal::proxy

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>,
Marcus Obst <mobst@schlittermann.de>

=head1 STATUS

   API:  stable
   DOC:  unstable

=cut

# vim:sts=3 sw=3 aw ai sm:
