package OASIS::WindowsServer;
use strict;
#$Id$
use IO::Socket::INET;
use IO::Select;
use Proc::Background;
use OASIS::Logger;

sub new {
	my $class = shift;
	my $args = shift;
	my $self = {};
	$self->{config}      = delete $args->{config}   || die "no config";
	$self->{max_workers} = delete $args->{max_workers};    # not used currently
	$self->{BinPath}     = delete $args->{BinPath}  || '.';
	$self->{port}
		= exists $args->{port}
		? delete $args->{port}
		: $self->{config}->get("server:port");
	$ENV{logfile} = $self->{config}->get("global:logfile");
	return bless $self,$class; 
}

sub DESTROY {

}

sub _bind {
	my $self = shift;
	die "no port defined " unless $self->{port};
	#print "Opening Listening Socket on port ".$self->{port}."\n";
	$self->{server} = IO::Socket::INET->new(
			Listen => 5,
			LocalPort =>  $self->{port}, 
		) or die $!."cant open server port";
	my $select = IO::Select->new();
	$select->add( $self->{server} );
	$self->{server_select} = $select;
	return $self->{server}; 	
}


sub run {
	my $self = shift;
	$self->_bind();
	my $server = $self->{server};
	while(1){
		#check for Pending IO on all sockets
		my @ready = $self->{server_select}->can_read(); #(server+clients+workers) will block
		
		# server can accept a new connection
		my @server = grep { $server eq $_ } @ready;
		if ( scalar @server ) {
			my $client_socket = $server->accept();
			#spawn new worker
			my ($worker_handle, $worker_socket) = $self->_run_worker();	
			$self->register_client( {
					worker_socket => $worker_socket,
					worker_handle => $worker_handle,
					client_socket => $client_socket,
			});
		}
		#find clients/workers that have pending IO
		my @others = grep { $_ ne $server } @ready;
		my @clients = map { exists $self->{workers}->{$_} ? $self->{workers}->{$_} : $_ }  @others;
		my $client_hash = {};
		$client_hash->{$_} = 1 for @clients;
		for my $client_key( keys %$client_hash ){
			$self->dispatch_sockets( $client_key );
		}
		
	}
}

sub register_client {
	my ($self, $args ) = @_;
	$self->{clients} = {} unless $self->{clients};

	my $client_socket = $args->{client_socket};
	my $worker_socket = $args->{worker_socket};
	my $worker_handle = $args->{worker_handle};
	my $select = IO::Select->new();
	$select->add( $args->{worker_socket} , $args->{client_socket} );
	$args->{select} = $select;
	$self->{server_select}->add( $args->{worker_socket} , $args->{client_socket} );

	$self->{workers}->{ $worker_socket } = $client_socket; 
	my $client_hash = { $client_socket => $args   };
	$self->{clients} = { %{$self->{clients}}, %$client_hash };

}

sub cleanup_client {
	my ($self, $client_key) = @_;
	#remove sockets from global select
	$self->{server_select}->remove( $self->{clients}->{$client_key}->{worker_socket});
	$self->{server_select}->remove(	$self->{clients}->{$client_key}->{client_socket});
	#delete internal information, close sockets and kill worker
	my $worker_socket =$self->{clients}->{$client_key}->{worker_socket};
        delete $self->{workers}->{$worker_socket};	
	$self->{clients}->{$client_key}->{worker_socket}->close();
	$self->{clients}->{$client_key}->{client_socket}->close();
	$self->{clients}->{$client_key}->{worker_handle}->die();
	delete $self->{clients}->{$client_key};
}

sub dispatch_sockets {
	my ($self, $key) = @_;
	logger(DEBUG, "Dispatching Socket IO");
	my $client_socket = $self->{clients}->{$key}->{client_socket} or die "no client socket";
	my $worker_socket = $self->{clients}->{$key}->{worker_socket} or die "no worker socket";
	my $select        = $self->{clients}->{$key}->{select};
	my $recipient     = {
		$client_socket, $worker_socket,
		$worker_socket, $client_socket, 	
	};
	
	#which socket has io pending?
	my @ready = $select->can_read();
	for my $socket ( @ready ) {
		my $buffer;
		my $read_size = $socket->sysread( $buffer, 1024 * 8 );
		if ( $read_size ) { # normal read
			$recipient->{$socket}->syswrite($buffer);
		}elsif( not defined $read_size){ #horrible read error
			$self->{clients}->{$key}->{closed}++;
		}elsif( $read_size == 0 ){  #connection closed
			$select->remove( $socket);
			$recipient->{$socket}->shutdown(1);
			$self->{clients}->{$key}->{closed}++;
		}
	}
	#if both sockets are cloed we cleanup the worker/client connection
	if ( $self->{clients}->{$key}->{closed} >= 2 ){
		$self->cleanup_client($key);
	}
}




sub _run_worker {
	my ( $self ) = @_;
	#open some random port 
	my $proc_socket   = IO::Socket::INET->new(
		Listen    => 1,
	) || die "cant open intermediary worker socket";

	my $proc_port = $proc_socket->sockport();

	#spawn worker.pl <socket port > -> it will open a own socket, connect to ours and tell us the port 
	my $proc_handle = Proc::Background->new($^X, $self->{BinPath}.'/worker.pl', $proc_port) || die $!." cant open worker";	

	#let him connect & tell us his port
	my $worker_init_socket = $proc_socket->accept() || die "accept failed on worker connect";
	my $worker_port;
	$worker_init_socket->sysread( $worker_port , 1024 * 8 ) or die "worker didnt send his port";

	#connect to his port
	my $worker_socket = IO::Socket::INET->new('127.0.0.1:'.$worker_port) || die "cant connect to worker on port $worker_port";
	return ($proc_handle, $worker_socket);
}
1;





