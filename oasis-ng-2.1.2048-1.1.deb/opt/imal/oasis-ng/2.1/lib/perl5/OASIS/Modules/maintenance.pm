package maintenance;

# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Modules/maintenance.pm $
# $Id$

use strict;
use warnings;
use OASIS;
use POSIX;
use File::Temp;
use File::Basename;
use Carp;

my $ID = 42;
my $REVISION = 9876;

my $release = "2.0";
our $VERSION = $release.'.'.$REVISION;

sub new {
   my $class = ref $_[0] ? ref shift : shift;
   return bless {}, $class;
}

sub get_status { goto &status }

sub status {
   return {
      pid => "sagichnicht"
   }
}

# The *_config() methods rely on the existence of a global

sub get_config() {
   my $self = shift;
}

sub set_config() {
   my $self = shift;
   die "setting complete config is not supported yet" if @_ == 1;

}

sub install {
   my ($self, $data, $fname) = @_;
   my $fh;

   if ($fname) {
      $fh = new IO::File(">$fname");
   }
   else {
      $fh    = new File::Temp;
      $fname = $fh->filename();
   }
   die "Can't open >$fname: $!\n"
      if not $fh;

   $fh->print($data) or die("update: Couldn't write to $fname: $!\n");
   $fh->close;

   my $pid = fork();
   if (not defined $pid) {
      die "Can't fork: $!";
   }
   if ($pid == 0) {
      chdir "/";
      open(X, ">/tmp/log");
      print X "\n\n======== " . localtime() . "\n";
      close(X);
      setsid();
      warn("called setsid for rpm -U...");
      system("rpm -U --force -v $fname >>/tmp/log 2>&1");
      exit 0;
   }
   waitpid($pid, 0);
   { local @ARGV = ("/tmp/log");
	local $/ = undef;
	$_ = <>;
   }
   return $_;
}

sub get_permissions()  { }
sub set_permissions()  { }
sub save_permissions() { }

sub list_certs()   { }
sub upload_certs() { }
sub remove_certs() { }

sub list_servers()   { }
sub upload_servers() { }

# -- private

sub _get_meta($) {
      my $mod = shift;
      local $/ = undef;

      open( X, $mod ) or croak "Can't open $mod: $!";
      my $content = <X>;
      close(X);

      my ( $p ) = $content =~ /^\s*package\s+(\S+?)\s*;/xms;
      my $v;
      for my $algorithm ( _get_versioning_algorithms($mod,$content) ){
            last if $v = $algorithm->();
      }
      return (
         version => ( defined $v ? $v : "n.A." ),
         package => ( defined $p ? $p : "n.A." ),
         error   => ( $@ ? $@ : "" )
      );
}

sub _get_versioning_algorithms {
    my( $filename, $content ) = @_;
    my $by_SVN_Id = sub {
        #$Id$
        my $IdString = $1 if $content =~ m/\$Id:\s*   #start
                                          ([^\$]+?)   #something
                                          \$          #end
                                          /xms;
        my ($script, $revision, @stuff ) = split /\s+/, $IdString;
        return $revision;
    };
    my $by_LastCRev = sub {
        #$LastChangedRevision: 1 $
        my $revision = $1 if $content =~ m/\$LastChangedRevision:\s*  #start
                                          ([^\$\s]+?)                 #something
                                          \s*\$                       #end
                                          /xms;
        return $revision;
    };
    my $by_loading = sub {
      my ( $p ) = $content =~ /^\s*package\s+(\S+?)\s*;/xms;
      my $v;
      local @INC = @INC;
      eval{
            local $SIG{__DIE__};
            require $filename;
            my $fake_self = {};
            bless $fake_self , $p;
            $v = $fake_self->VERSION;
      };
      return $v;
    };
    return ( $by_SVN_Id, $by_LastCRev, $by_loading  );
}

1;
__END__

use vars qw(@ISA $VERSION);

$VERSION = (split(" ", q$Rev: 4195 $)[1]);

sub status {
   my $self = shift;
   my $status;

   $status->{'db_file'} = $self->{state}->{config}->{daemon}->{'db_file'};
   $status->{'date'}    = $self->{state}->{config}->{daemon}->{'date'};
   $status->{'time'}    = $self->{state}->{config}->{daemon}->{'time'};
   $status->{'os'}      = $self->{state}->{config}->{daemon}->{'os'};
   $status->{'ssl_key_file'}
      = $self->{state}->{config}->{daemon}->{'ssl_key_file'};
   $status->{'listenaddr'}
      = $self->{state}->{config}->{daemon}->{'listenaddr'};
   $status->{'pid'}     = $self->{state}->{config}->{daemon}->{'pid'};
   $status->{'timeout'} = $self->{state}->{config}->{daemon}->{'timeout'};
   $status->{'ssl_cert_file'}
      = $self->{state}->{config}->{daemon}->{'ssl_cert_file'};
   $status->{'minport'}  = $self->{state}->{config}->{daemon}->{'minport'};
   $status->{'strftime'} = $self->{state}->{config}->{daemon}->{'strftime'};
   $status->{'logfile'}  = $self->{state}->{config}->{daemon}->{'logfile'};
   $status->{'logsize'}  = $self->{state}->{config}->{daemon}->{'logsize'};
   $status->{'maxport'}  = $self->{state}->{config}->{daemon}->{'maxport'};
   $status->{'numofknechte'}
      = $self->{state}->{config}->{daemon}->{'numofknechte'};
   $status->{'basepath'} = $self->{state}->{config}->{daemon}->{'basepath'};
   $status->{'version'}  = $self->{state}->{config}->{daemon}->{'version'};
   $status->{'path'}     = $self->{state}->{config}->{daemon}->{'path'};
   $status->{'port'}     = $self->{state}->{config}->{daemon}->{'port'};
   $status->{'service'}  = $self->{state}->{config}->{daemon}->{'service'};

   $status->{modules} = $self->{state}->{config}->{modules};

   return \$status;
}

sub set_certificate {
   my ($self, $certdata, $rule) = @_;

   my $file;
   my @names = [];
   my $newname;
   my $cli_cert = $certdata;
   $cli_cert = $1
      if $cli_cert
      =~ /BEGIN CERTIFICATE\s*[\-]+\s*(.+?)[\-]+\s*END CERTIFICATE/si;
   $cli_cert =~ s/\s+//g;
   $cli_cert =~ s/\r+//g;
   $cli_cert =~ s/\n+//g;

   opendir(DIR, $self->{state}->{config}->{daemon}->{basepath} . '/ca')
      or die "Fehler! Konnte Verzeichnis "
      . $self->{state}->{config}->{daemon}->{basepath} . '/ca'
      . " nicht oeffnen: $!";    #Verzeichnis öffnen

   while (defined($file = readdir(DIR))
      )                          #Alle Dateien des Verzeichnisses bearbeiten
   {
      push(@names, $file);
      next if $file eq '..' or $file eq '.' or $file eq 'ql13m37s';
      my $fh = IO::File->new("< "
                      . $self->{state}->{config}->{daemon}->{basepath} . '/ca'
                      . "/$file")
         or die "Couldn't open "
         . $self->{state}->{config}->{daemon}->{basepath} . '/ca'
         . "/$file for reading: $!\n";
      my $content;
      read $fh, $content, -s $fh;
      $content = $1
         if $cli_cert
         =~ /BEGIN CERTIFICATE\s*[\-]+\s*(.+?)[\-]+\s*END CERTIFICATE/si;
      $content =~ s/\s+//g;
      $content =~ s/\r+//g;
      $content =~ s/\n+//g;

      if ($content eq $cli_cert) {
         $self->{state}->{config}->{daemon}->{certificates}->{$file} = $rule;
         $self->{configstring}->{set_cert}->{$file} = $rule;
         return \"rights have been replaced";
      }
   }

   my $count = 37;
SEARCHNAME: while (1) {
      $count++;
      $newname = 'ql13m' . $count . 's';
      for (@names) {
         $newname = undef if $newname eq $_;
      }
      last SEARCHNAME if $newname;
   }
   open(FH,
             "> "
           . $self->{state}->{config}->{daemon}->{basepath} . '/ca'
           . "/$newname"
      )
      or die "could not open " . "> "
      . $self->{state}->{config}->{daemon}->{basepath} . '/ca'
      . "/$newname"
      . " for reading";
   print FH $cli_cert;
   close(FH);
   $self->{state}->{config}->{daemon}->{certificates}->{$newname} = $rule;
   $self->{configstring}->{set_cert}->{$newname} = $rule;
   return \"the rights for the new certificate have been set";
}

sub register {
   my $self = shift;
   my $host = shift;

   my $crtfl = $self->{state}->{config}->{daemon}->{basepath}
      . '/certs/client-cert.pem';
   my $envfl = $self->{state}->{config}->{daemon}->{basepath}
      . '/etc/hostconfig.xml';

   print "PATH: $envfl\n";

   #print XMLin($envfl);

#my $lst = OASIS::OASIS->new({ host => $host, port => 8086, certfile => $crtfl, service => 'Leitstand' }) or warn $!;

   #$lst->Record({ db => $dbref, env => XMLin($envfl) });
}

sub unregister {
   my $self = shift;
}

sub restart {
   my $self    = shift;
   my $service = shift;
   my $port    = shift;

   $service = 'watchdog' unless defined($service);
   unless (defined($port)) { $port = $service !~ /^worker$/ ? 8087 : 8086; }

   if ($service =~ /^watchdog$/) {
      if ($self->{state}->{config}->{'daemon'}->{'service'} =~ /^watchdog$/) {
         $self->flog_ts(
            "$$: Cannot restart watch dog! Watch dog process already running!"
         );
         return \undef;
      }
      my $cmd .= ' --path=' . $self->{state}->{config}->{'daemon'}->{'path'};
      $cmd    .= " --service=watchdog";
      $self->{configstring}->{run_self} = $cmd;
   }
   elsif ($service =~ /^worker$/) {
      if ($self->{state}->{config}->{'daemon'}->{'service'} =~ /^worker$/) {
         $self->flog_ts(
                "$$: Cannot restart worker! Worker process already running!");
      }
      my $cmd .= ' --path=' . $self->{state}->{config}->{'daemon'}->{'path'};
      $cmd    .= " --service=nowatchdog";
      $self->{configstring}->{run_self} = $cmd;
   }

}

use constant NORMAL_PRIORITY_CLASS => 32;
use constant DETACHED_PROCESS      => 8;

sub _run_detached {
   my $self = shift;
   my $cmd .= ' --path=' . $self->{state}->{'daemon'}->{'path'};
   $cmd    .= " --service=" . $self->{state}->{'daemon'}->{'service'}
      if $self->{state}->{'daemon'}->{'service'};
   $self->{configstring}->{run_self} = $cmd;
}


sub shutdown {
   my $self = shift;
   my $arg  = shift;
   $self->{configstring}->{shutdown} = 1;
   return \"shutdown in progress";
}

sub reload # order of execution is maintainance->dispatcher(reload is scheduled)->knecht
{
   my $self = shift;
   $self->{configstring}->{become_dispatcher} = 1;
   return \1;
}

sub change_config {
   my $self               = shift;
   my $key_value_hash_ref = shift;

   $self->{configstring}->{change_config} = $key_value_hash_ref;
   return \'restarting, this could take a while';
}

sub _get_modul_info {
   my ($self, $mname, $mdata) = @_;

   my $module = $mname = _basename($mname);
   $module =~ s/\.pm$//;
   my $fname = $self->{state}->{config}->{daemon}->{path} . "/$mname";
   my $version = $mdata =~ /\$LastChangedRevision:\s+(\d+)\s+\$/ ? $1 : undef;

   return ($module, $fname, $version);
}

sub set_module {
   my ($self, $mname, $mdata) = @_;

   my $errno = "OK";
   my ($module, $fname, $version) = _get_modul_info($self, $mname, $mdata);

   if ($version) {
      $self->{configstring}->{modules}->{"$module"}->{version} = $version;
      $self->{configstring}->{modules}->{"$module"}->{fname}   = $fname;

      my $fh = IO::File->new("> $fname")
         or die "Couldn't open $fname for writing: $!\n";
      binmode $fh;
      $fh->print($mdata) or die "Couldn't write to $fname: $!\n";
      print("$$: set_module: $module, $fname, $version: $errno");
      $fh->close;
      $self->{configstring}->{'set_classes_to_handle'} = $mname;
      $self->reload();
   }
   else {
      die "No version found in modul";
   }

#   delete $INC{$fname};                            # Force reload (dosn't work)
   \"$fname: $errno - " . $version . " reload may take a while";
   return \undef;
}

sub print_modules {
   my $self = shift;
   my @a;

   push @a, $_ for keys %{ $self->{state}->{config}->{modules} };

   return \@a;
}

sub rm_module {
   my ($self, $mname) = @_;

   my ($module, $fname, $version) = _get_modul_info($self, $mname, undef);

   if (exists $self->{state}->{config}->{modules}->{"$module"} and -e $fname)
   {
      $self->{configstring}->{modules}->{"$module"} = 'delete';
      reload($self);
      unlink $fname;
      return ("$$: rm_module: succesfull: removed $module ($fname)");
   }
   else {
      if (-e $fname) {
         die "$fname not found";

      }
      die("$$: rm_module: failed to remove $module ($fname)");
      return undef;
   }
}

sub flog_ts {
   my ($self, $msg) = @_;
   $msg = strftime("%Y-%m-%d %H:%M:%S ", localtime()) . "# $msg\n";
   print $msg;
   my $logfile = new IO::File;
   $logfile->open(">> " . $self->{state}->{config}->{daemon}->{logfile})
      || warn("Can't open $self->{db}->{daemon}->{logfile}: $!\n");
   flock($logfile, LOCK_EX)
      || warn("Can't lock " . $self->{db}->{daemon}->{logfile} . " $!\n");
   $logfile->print($msg)
      || warn("Can't write " . $self->{db}->{daemon}->{logfile} . " $!\n");
   flock($logfile, LOCK_UN)
      || warn("Can't unlock " . $self->{db}->{daemon}->{logfile} . " $!\n");
   $logfile->close
      || warn("Can't close " . $self->{db}->{daemon}->{logfile} . " $!\n");

   return \$msg;
}

sub dump_dbref {
   my $self = shift;
   return $self->flog_ts(Dumper($self->{state}));
}

sub _basename {
   $_ = shift;
   s/^.*\///;
   return $_;
}

sub _dirname {
   $_ = shift;
   s/\/[^\/]+$//;
   return $_;
}

1;
__END__

=head1 NAME

maintainance - A Maintenance class

=head1 SYNOPSIS

    use OASIS;

    $m = new OASIS({ service => "maintainance" });

    $hash_ref = $m->status();

    $scalar = $m->get_config(session => "max_age");
    $m->set_config(session => "max_age", 100);
    $m->save_config();
    $m->clear_config();

    $m->install($file);


=head1 DESCRIPTION

Maintainance module for the OASIS framework.

=head1 METHODS

Several methods are available, the following list is grouped.

=head2 Common methods

=over

=item CONSTRUCTOR new( )

Constructor for the daemon maintainance object. Returns a reference to a
maintainance object.

=back

=head2 Status methods

=over

=item status( )

=item get_status( )

Returns a hash ref containing the current server status. B<NOTE>: this
hash reference is B<not> compatible with the one from the 1st generation
Oasis.

=back

=head2 Config methods

All these methods rely on the existence of a global C<$OASIS::CONFIG>
variable. Usually this variable is provided by the L<OASIS::Session>
module.

=over

=item get_config([I<group> => I<parameter>])

Returns the value of the given parameter. If nothing is passed to the
C<get_config()> call, it returns the complete config as a hash
reference.  This hash reference is basically a ref to the C<{v}> part of
C<Config::IniFile> object.

For some reason the C<Data::Dumper> doesn't work as expected, but the
following example works:

    use Data::Dumper;
    use Config::IniFiles;   # this *has* to be "used"!

    my $m = new OASIS({ service => "maintainance" });
    print Dumper $m->get_config();

Just reading one config item is no problem either.

=item set_config(I<group> => I<parameter>, I<value>)

Set the given parameter to a new value. The parameter B<must> exist. You
B<can't> add new parameters! The config file is not changed and the
value is only valid for the current process (see C<save_config()>).

=item save_config( )

Save the running config to the file named in C<global:running_config>.
The file is modified only if the configuration is considered "dirty"
(after calling C<set_config()>). The saved config will be picked up from
new as well es from running processes (as long as they really "ask" the
config object). Of course, for some changes a server restart is
mandatory (currently).

=item clear_config( )

Remove the running config file.

=back

=head2 Module methods

=over

=item list_modules( )

This returns a list of all currenlty used/installed modules in all
directories "global:module_path" (a config item). The returned list  is
a list of hash refs about as follows:

    (
        { package => "package name",
          version => "package version",
          file => "file name",
          stat => stat($file),
        },
        { ...
        }, ...
    )

=item upload_modules(I<name> => I<code>[, ...])

=item upload_modules({ dir => I<directory>, overwrite => I<TRUE|FALSE>},
   I<name> => I<code>[, ...])

Just upload a list of modules.  Per default they are stored int the directory
given by the config option F<global:module_path>. This directory gets created
automagically (if F<global:create_missing_dirs> is "yes"). Additionally you
may pass some options:

=over

=item dir

The directory to save the modules in (default: first directory in
"global:module_path"). This directory has to exist!

=item overwrite

If were are allowed to overwrite your modules with other ones. (default:
no)

=back

=head2 Example

      use OASIS;
      my $m = new OASIS ({service => "maintenance"});
      open(my $module, "module.pm");
      $m->upload_modules("module.pm" => join "", <$module>);

The list of successfully installed modules is returned.

=item remove_modules(I<module>[,...])

C<remove_modules()> traverses the module path (as in
C<global:module_path>) and deletes all F<.pm> (auto-appended) files, if the name fits.
Returns a list of sucessfully deleted modules (filenames).

=back

=head1 INSTALL/UPDATE methods

=over

=item install( I<data> [, I<filename> ] )

Upload and install the whole package. Tries to do some automagic
detection of package type. (Currently only RPM is implemented).
The I<filename> is NOT the package name!

=back

=head1 SEE ALSO

leitstand, networker, joschyd

=head1 AUTHOR

Frank-Peter Reich, Maik Schueller - SAP Systems Integration AG, Hosting,
Technical Basis, heavily modified by Heiko Schlittermann


=head1 COPYRIGHT

Copyright (C) 2002-2003 SAP Systems Integration AG. All Rights Reserved.

This library is free software; you can redistribute it and/or
modify it under the same terms as Perl itself.

=cut
