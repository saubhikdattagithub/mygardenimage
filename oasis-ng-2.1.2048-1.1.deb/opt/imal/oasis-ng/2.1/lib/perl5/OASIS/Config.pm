package OASIS::Config;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id$
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Config.pm $

use 5.8.0;
our $VERSION = (split " ", q$Rev: 3414 $)[1];

use strict;
use warnings;
use Carp;
use Cwd qw(abs_path);
use Config::IniFiles;
use FindBin qw($Bin);    # slows down?
use IO::File;
use Cwd qw(abs_path);
use Hash::Util qw(lock_keys);
use OASIS::Logger;
use OASIS::Tools qw(:all);
use if $ENV{DEBUG} => "Smart::Comments";
use Readonly;

Readonly my $SIGNAL => $OS_CLASS eq 'win32' ? "KILL" : 'USR1';

sub new {
   my $class = ref $_[0] ? ref shift : shift;
   my $self = bless { file => { static  => "",
                                running => "",
                      },
                      dirty       => undef,
                      config      => undef,
                      pid         => $$,
                      sig         => $SIGNAL,
                      sig_handler => undef,
   }, $class;
   lock_keys(%$self);

   # we save the signal name and the handler for later
   # checks (see save())
   $SIG{ $self->{sig} } = $self->{sig_handler} = sub {
      debug("reloading config $self->{file}{running}");
      $self->reload();
   };

   # we do not need to search if there's a defined
   # config file
   if (defined $_[0]) {
      $self->{file}{static} = abs_path(shift) if @_;
      croak "config file ($self->{file}{static}): $!\n"
         if not -r $self->{file}{static};
   }
   else {
      my $root_inode = (stat "/")[1];
      my $dir        = $Bin;

      my @tested;
      my $file = "$dir/oasis.conf";
      for ($dir = $Bin; (stat $dir)[1] != $root_inode; $dir .= "/..") {
         $file = "$dir/etc/oasis/oasis.conf" if not $file;
         ### testing: $file
         last if -r $file;
         push @tested, $file;
         undef $file;
      }
      croak "no config file found (",
         join(" ", map { do 1 while s{/[^/]+?/\.\./}{/}; $_ } @tested), ")"
         if not $file;
      $self->{file}{static} = $file = abs_path($file);
   }

   ### found: $self->{file}{static}

   my $static = new Config::IniFiles(-file => $self->{file}{static})
      or croak("Config::IniFiles $! ($@)");

   if (defined(my $f = $static->val(global => "running_config"))) {

      # some Hexerei: we can't pass the file name of the running
      # config since this file may not exist and this seems to be
      # problematic for Config::IniFiles.
      my $running;
      if (-f $f and -s _) {
         croak "can't read running config from $f: $!" if not -r $f;
         $self->{config} =
            new Config::IniFiles(-file   => $f,
                                 -import => $static);
      }
      else {
         $self->{config} = $static;
         $self->{config}->SetFileName($f);
      }
      $self->{file}{running} = $f;
   }
   else {
      carp "no global:running_config found in ini file(s)";
      $self->{config} = $static;
      $self->{file}{running} = "";
   }
   ### static: length($static)
   ### config: $self->{config}
   return $self;
}

sub files { %{ shift->{file} } }

# FIXME: I'm not sure if it will work, since it can happen(?) that we're
# not root anymore. Probably we've to use the above opened file handle.
sub save {
   my $self = shift;
   return if not $self->{dirty};

   if (not $self->{config}->val(global => "running_config")) {
      carp "Can't save, no running config file";
      return 0;
   }

   ### X: $self->{config}->GetFileName()

   $self->{config}->RewriteConfig();

   # If our PID is not the pid of the creator, we have to
   # notify the creator
   if ($self->{pid} != $$) {

      croak "Oooo, signal handler replaced by third party, "
         . "can't notify master ($self->{pid})"
         if $self->{sig_handler} ne $SIG{$SIGNAL};

      # ask the "master" for reloading the config
      kill $SIGNAL => $self->{pid};
   }
}

sub get_config { return shift->{config}{v} }
sub val        { croak "do not use val() anymore!" }

sub is {
   my ($self, $key) = @_;
   $self->get($key) =~ /^(yes|true|1)/i;
}

sub get {
   my $self = shift;
   return @_ == 2
      ? $self->{config}->val(@_)
      : $self->{config}->val(split /:/, $_[0]);
}

sub set {
   my $self = shift;
   $self->{dirty} = 1;
   ### @_
   return @_ == 3
      ? $self->{config}->setval(@_)
      : $self->{config}->setval(split(/:/, $_[0]), $_[1]);
}

sub clear {
   unlink shift->{config}->GetFileName();
}

sub reload {
   shift->{config}->ReadConfig();
}

sub adhoc {
   require File::Basename;
   import File::Basename;
   require File::Temp;
   import File::Temp qw(tempdir tmpnam);
   $File::Temp::KEEP_ALL = 1;

   my $cf;

   our @tempfiles;
   our $thispid = $$;
   END { unlink(@tempfiles) if defined $thispid and $$ == $thispid }

   my $running  = (new File::Temp)->filename;
   my $pidfile  = (new File::Temp)->filename;
   my $portfile = (new File::Temp)->filename;
   my $ssl_key  = (new File::Temp)->filename;
   my $ssl_crt  = (new File::Temp)->filename;
   my $sessions = (tempdir(CLEANUP => 1));

   # my $module_path  = (tempdir(CLEANUP => 1));
   my $module_path  = tmpnam();                   # only the name!
   my $package_file = map_to_file(__PACKAGE__);

   #no warnings "once";
   open(my $data, $package_file);
   local $_ = join "", <$data>;
   /(^-+BEGIN.*?KEY.*?^-+END.*?$).*/ms;
   open(O, ">$ssl_key");
   print O "$1\n";
   close(O);
   /(^-+BEGIN.*?CERT.*?^-+END.*?$).*/ms;
   open(O, ">$ssl_crt");
   print O "$1\n";
   close(O);
   close($data);

   $cf = new File::Temp
      or croak "Can't create tmpfile";
   print {$cf} <<_EOF;
      [global]
         running_config = $running
         module_path = $module_path
         create_missing_dirs = yes
      [session]
         dir = $sessions
         max_age = 86400
         cleanup_interval = 300
      [server]
         port = 0
         pid_file = $pidfile
         port_file = $portfile
         ssl_key = $ssl_key
         ssl_crt = $ssl_crt
_EOF
   close($cf);
   return $cf->filename();
}

sub DESTROY {
   my $self = shift;
   return if not $self->{dirty};

   # croak "dirty config not saved!";
}

1;
__END__

=head1 NAME

OASIS::Config - config file handling

=head1 SYNOPSIS

    use OASIS::Config;

    $conf = new OASIS::Config;
    $a = $conf->get(group => "item");
    $a = $conf->get("group:item");

=head1 DESCRIPTION

When creating a new object, the following actions take place:

=over

=item 1

If there is no config file name is passed (or the passed value is
C<undef>) we start searching a for a config file:

   ./oasis.conf
   ../etc/oasis/oasis.conf
   ../../etc/oasis/oasis.conf
   ../../../etc/oasis/oasis.conf

and so on, until we can't ascent any more B<or> until we find a 
config file. A config B<has> to be found.

If a config is found,
there B<should> be at least one config item F<global:running_config>,
pointing to the location to save the running config (used by the
C<save()> method.

A warning is issued if there's no item F<global:running_config> found.

=item 2

The running config is read B<if> we know the location and if it exists,
overriding all previous values.

=back


=head1 OBJECT METHODS

=over

=item CONTRUCTOR new([I<config-file>])

See above about what this method is doing.  Croaks if there is 
no configuration file readable. 

=item get(I<section> => I<parameter>)

This returns the value for the I<parameter> in the I<section>. Alternative
syntax is allowed: C<get(I<section>:I<parameter>)>.

=item set(I<section>, I<parameter> => I<value>)

This sets a value in the current config and marks the config B<dirty>.
Alternative syntax C<< set(I<section>:I<parameter> => I<value>) >> is
allowed too.

=item is(I<section>, I<parameter>)

Returns a true value, if the option is "yes", "true", or "1". Alternative
syntax is allowed here too.

=item get_config( )

This returns a hash ref containing the complete configuration.

=item set_dirty( )

Mark the current config dirty, thus the C<save()> method will save it.

=item save( )

This saves the running config, but B<only> if it is marked B<dirty>.

=item files( )

Returns a a hash with the static and the running (current) config file
name.

   %files = $config->files();
   print "static : $files{static}\n";
   print "running: $files{running}\n";

=item reload()

Re-Read the current config file (should be the running config file)

=item adhoc()

Creates a temporary ad-hoc configuration which should fit the most
test cases. The filename of the created config is returned.

=back

=head1 CONFIG

The following config items are used:

=over

=item global:running_config

Name of the file for the running configuration.

=item global:create_dirs

Controls if we should create missing directories.

=back

=head1 BUGS

The config file(s) passed to the constructor are not allowed to be
empty. Actually this seems to be a bug of L<Config::IniFiles>.

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

=cut

# it's here to create temporary ssl
-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQCkibhy2a/waPtSRB7nhbJu84rccSO4jfznY3LMkg98axqAUpiw
EeUHFDVA7sty8vu/gDGnJVQBnWmh8nlgQflNRzNCDDgDAQw9kXZZgD5hjwW/sytr
RNa8qG1znl0jlPZyaPGuePmF7Tz/gE88rbxOKmaqsE16633bQSGsLkO6GQIDAQAB
AoGAIxVShPqxrxtTa0knJcq2Lz4yv6pIKZPs9xGXatNCBg94SSBTekd2hDnk2QGR
0+LHlx+odrFY5jdATM28369xjpci73ZxhanlvmNYwlZbjFczyjSScuykiA7XqAM4
VS4VjjQa187WwQyagYhsM6QS8eeJ9zcJI4Z9JiXmfIJLfHkCQQDWUq/TzUgKPM10
p+LsjIenYMCWJnDnHbK1RnQ9s5opku8lu+QaQM1MYJbMUY1a/jgdbG4tnnYbdBCU
wr+Sm5OHAkEAxIipf3FcMDw3HkBFbEXTQmXqCf3Xr2b0H8jRhoqIUArNpZrFPw4F
G1F4OKF2TqDPxG8HeY3QKyX0rfin7mztXwJBANFslOEK25UdWsnd71Cj9T4pvaY6
w+IiU+jsglN0d3SeXk7p7Xd10OYMD+5w1gaPGPgvZu3uxIwI+tbSAe5ZVWsCQQCB
IFVVEXMDkhyYuJukRsBF6NX7WJfEe707wOLBJfXnuSFihCzCgACk8UMu2g70HD5G
Drj3iVBTeS2ovC4Bvfm7AkBOEAXYpZnN6BBhGXrwIWnJptPRwUa90b+oEtpknhFc
aSPwloU27gsHF9o+eHTo2n/auKU3K2Q3fLYv5vSqAUg/
-----END RSA PRIVATE KEY-----

-----BEGIN CERTIFICATE-----
MIICSDCCAbGgAwIBAgIBADANBgkqhkiG9w0BAQQFADBqMQswCQYDVQQGEwJERTEU
MBIGA1UECBMLRGV1dHNjaGxhbmQxEDAOBgNVBAcTB0RyZXNkZW4xDjAMBgNVBAoT
BVNBUFNJMQswCQYDVQQLEwJUQjEWMBQGA1UEAxMNd3d3LnNhcC1zaS5kZTAeFw0w
NDA5MjExNDI0MDBaFw0xNDA5MTkxNDI0MDBaMGoxCzAJBgNVBAYTAkRFMRQwEgYD
VQQIEwtEZXV0c2NobGFuZDEQMA4GA1UEBxMHRHJlc2RlbjEOMAwGA1UEChMFU0FQ
U0kxCzAJBgNVBAsTAlRCMRYwFAYDVQQDEw13d3cuc2FwLXNpLmRlMIGfMA0GCSqG
SIb3DQEBAQUAA4GNADCBiQKBgQCkibhy2a/waPtSRB7nhbJu84rccSO4jfznY3LM
kg98axqAUpiwEeUHFDVA7sty8vu/gDGnJVQBnWmh8nlgQflNRzNCDDgDAQw9kXZZ
gD5hjwW/sytrRNa8qG1znl0jlPZyaPGuePmF7Tz/gE88rbxOKmaqsE16633bQSGs
LkO6GQIDAQABMA0GCSqGSIb3DQEBBAUAA4GBAKACk0BgT3mrmQFHOhy5B5LP+UDM
5izjlN69zJ4R6mDyNOUVjZQpL5th28Hnh/PHHwgY2jeD1+5uKKpfsQoP3i4PC62u
IZhNtFxym7Y09wxulZwWDrKbqhkxhQAov/GDLOagjwcYKkq2+s0ZhgfTavcOywBi
q2fILh5R6ZbD+fdf
-----END CERTIFICATE-----


# vim:sts=3 sw=3 aw ai sm:

