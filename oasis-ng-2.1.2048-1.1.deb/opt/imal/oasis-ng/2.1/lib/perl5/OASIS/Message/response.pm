package OASIS::Message::response;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id: /local/sapsi/branch/ng/oasis/scratch/message/request.pm 10 2007-03-03T07:57:08.315076Z heiko  $
# $URL: /local/sapsi/branch/ng/oasis/scratch/message/request.pm $

use 5.8.0;
our $VERSION = (split " ", q$Rev: 17 $)[1];

use strict;
use warnings;
use Carp;
use base qw(OASIS::Message);
use if $ENV{DEBUG} => "Smart::Comments";
use Data::Dumper;
use OASIS::Logger;
{
   package RESPONSE;
   use Class::Struct RESPONSE => { sid         => '$',
                                   retval      => '$',
                                   os_error    => '$',
                                   child_error => '$',
                                   eval_error  => '$',
                                   cwd         => '$',
                                   user        => '$',
                                   uid         => '$',
                                   group       => '$',
                                   gid         => '$',
   };

   sub TO_JSON {
      my $self = shift;
      return {
          sid         => $self->sid         ,
          retval      => $self->retval      ,
          os_error    => $self->os_error    ,
          child_error => $self->child_error ,
          eval_error  => $self->eval_error  ,
          cwd         => $self->cwd         ,
          user        => $self->user        ,
          uid         => $self->uid         ,
          group       => $self->group       ,
          gid         => $self->gid         ,
      };
   }

   1;
}
sub new {
   my ($class, $argv) = @_;
   $class = ref $class if ref $class;

   my $self;

   if (my $fh = $argv->{stream}) {
      $self = $class->SUPER::new($argv);
      $self->{body} = RESPONSE->new(%{ $self->body } ) unless ref $self->body eq 'RESPONSE';
      return $self;
   }

   # create the REQUEST struct and cleanup the %$argv, then
   # we can pass the reset to our BASE class
   my $r = RESPONSE->new( %$argv );
   debug("reconstructed response ".Dumper($r)." from data".Dumper($argv));
   delete @{$argv}{ map { s/RESPONSE::// && $_ } keys %$r };

   $self = $class->SUPER::new($argv);
   $self->{body} = $r;

   return $self;

}

1;
__END__

=head1 NAME

message::response -- OASIS message request

=head1 SYNOPSIS

   use message::response;

   $request = new message::response({
      sid         => $session_id,
      retval      => 
      os_error    => $!,
      child_error => $?,
      eval_error  => $@,
   });

   $request = new message::response({
      stream     => \*STDIN
   });

=head1 DESCRIPTION

The "message::request" is basically a "message".  So all methods
of L<message> are available.

=head1 CONSTRUCTOR

=over

=item new { I<ARGS> }

Creates a new request.  The constructor takes a hash reference to the
following key/value pairs: B<method> is the name of the method to call.
It is the function call and some indirect objects (?), for instance
something like this:

   my $request = new message::request({
      method => "use demo"
   });

The B<argv> gets a reference to the argument vector as it should be
passed to the B<method>.  B<wantarray> is I<true> or I<false>, depending
on the context.  Normally it is autodetected.

Under some special circumstances you might want to pass a reference to 
your own B<serializer>.  This needs to be a subclass of L<serializer>.

=back

=head1 METHODS

There are accessor to the elements of the request.

=head1 SEE ALSO

L<message>, L<serializer>

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm:
