package OASIS::Logger::unix;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id: unix.pm 3419 2007-10-19 08:53:58Z heiko $
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Logger/unix.pm $

# Möglicherweise UniLog (CPAN)

our $VERSION = (split " ", q$Id: unix.pm 3419 2007-10-19 08:53:58Z heiko $)[1];

# back to the callers package
#
package OASIS::Logger;

use 5.8.0;
use strict;
use warnings;
use Unix::Syslog qw(:macros :subs);
use File::Basename;
use Carp;

sub _os_init {
   openlog(basename($0), LOG_PID | LOG_PERROR, LOG_LOCAL7);
}

sub _os_log {
   syslog(shift, join "", @_);
}

END { closelog }

1;
__END__

=head1 NAME

OASIS::Logger::unix - unix parts of OASIS::Logger

=head1 SYNOPSIS

    package OASIS::Logger;
    ...
    ...
    use base("OASIS::Logger::unix");

=head1 DESCRIPTION

This module implements the unix dependend parts of the L<OASIS::Logger>.

There are no user serviceable parts inside.

=head1 SEE ALSO

L<OASIS::Logger>, L<OASIS::Tools>

=cut

# vim:sts=4 sw=4 aw ai sm:
