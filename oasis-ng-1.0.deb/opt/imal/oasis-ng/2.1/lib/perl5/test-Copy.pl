use strict;
use warnings;
use FindBin qw($Bin);
use lib $Bin.'/lib';
use lib $Bin.'/CPAN_WIN/lib';
BEGIN{ 
$ENV{PATH} .= ";$Bin/CPAN_WIN/";}

use OASIS;

my $certfile = 'Z:\Oasis-install\r0.927\certs\client-cert.pem';

	my $oasis = OASIS->new({
		host => 'localhost',
		service => 'maintenance',
		certfile => $certfile,
	});

	use Data::Dumper;
my $count = 0;	
while (1){
	$oasis->status();
	print $count++."\n";

}
