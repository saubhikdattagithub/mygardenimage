package OASIS::Logger::win32;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id$
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Logger/win32.pm $

our $VERSION = (split " ", q$Id$)[1];

# back to the callers package
# thus we map our functions into the name space of the
# OASIS::Logger
package OASIS::Logger;
use FindBin qw/$Bin/;
use 5.8.0;
use strict;
use warnings;
use Carp;
#use Win32::EventLog;

#FIXME
 my $handle;
my $max_size = '10000000'; #10 MB
#use constant LOG_EMERG => "LOG_EMERG";

sub _os_init {
   my $ident = "[$$]";

#   $handle = Win32::EventLog->new($ident, $ENV{ComputerName});
}

sub _os_log {
	my $fh = _open_log() || return;
	print $fh join( ' ', @_)."\n";
	close $fh;
}

sub _open_log {
	my $fh;
	my $log_file = $ENV{logfile}; # this var is ser in WindowsServer.pm
	return unless $log_file;
	$log_file =~ s/\//\\/g;
	#check if log rotate is needed
	if( -f $log_file and -s $log_file > $max_size ){
		system( "copy $log_file $log_file".'.old' );
		open FH, '>'.$log_file;
		close FH;
	}
	open( $fh , '>>'.$log_file);
	return $fh;
}

sub LOG_EMERG  {return 'EMERG'}
sub LOG_ALERT  {return 'ALERT'}
sub LOG_CRIT   {return 'CRITICAL'}
sub LOG_ERR    {return 'ERROR'}
sub LOG_WARNING{return 'WARNING'}
sub LOG_NOTICE {return 'NOTICE'}
sub LOG_INFO   {return 'INFO'}
sub LOG_DEBUG  {return 'DEBUG'}

#END { $handle->Close() if $handle; }

1;
__END__

=head1 NAME

OASIS::Logger::win32 - win32 parts of OASIS::Logger

=head1 SYNOPSIS

    package OASIS::Logger;
    use base("OASIS::Logger::win32");

=head1 DESCRIPTION

This module implements the win32 dependend parts of the
L<OASIS::Logger>.

=head1 METHODS

No public methods. This package is just an implementation of the
OASIS::Logger for Win32.

=head1 SEE ALSO

L<OASIS::Logger>, L<OASIS::Tools>

=cut
# vim:sts=4 sw=4 aw ai sm:
