package OASIS::Session;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id$
# $URL: /local/sapsi/branch/ng/oasis/lib/OASIS/Session.pm $
use strict;
use warnings;

our $VERSION = (split " ", q$Rev: 3419 $)[1];

use Carp;
use Cwd qw(getcwd realpath);
use Fcntl qw(:flock);
use Storable qw(nstore_fd fd_retrieve);
use Hash::Util qw(lock_keys);
use File::Basename;

use OASIS::Logger;
use OASIS::Tools qw(&touch &on_windows &map_to_file);
use OASIS::AccessControlManager;

use if $ENV{DEBUG} => "Smart::Comments";

sub new {
   my $class = ref $_[0] ? ref shift : shift;
   my $argv = shift;

   my ($fd, $self);

   $self = { conf   => $argv->{conf},
             id     => $argv->{id},
             module => undef,
             fd     => undef,
             cwd    => undef,
             object => undef,
             allowed_modules => undef,
             acl    => OASIS::AccessControlManager->new,
   };

   if (not defined $self->{id}) {
      my $ug = $$.time;
      $self->{id} = $ug;
      debug("created new session $self->{id}");
   }
   else {
      debug("created continued session $self->{id}");
   }

   bless $self, $class;

   return $self;
}

sub id { $_[0]->{id} }

sub execute {
   my ($self, $arg) = @_;

   my $method    = $arg->{method};
   my $wantarray = $arg->{wantarray};
   my @argv      = @{ $arg->{argv} };
   my $remote_addr = delete($arg->{remote_addr}) || '';


   info("$method $ENV{REMOTE_USER}\@$remote_addr");
   my $retval;
   if( $method !~ /\s/ ) {
      $retval = eval{
            $self->execute_module_method({
               method => $method,
               wantarray => $wantarray,
            },
            @argv
         );
      }
   }elsif ( $method =~ /^(\S+)\s+(.*)/ ) {
      eval{
         $self->execute_special_method({
            action => $1,
            module => $2,
         },@argv);
      }
   }

   my $eval_error = $@;
   #stay backwards compatible with older clients
   undef $eval_error unless $eval_error;
   debug($@) if $@;
   if( $eval_error ){
      $eval_error =~ s{at lib.+$}{}sm;
   }


   my %result;

   $result{retval}      = $retval;
   $result{sid}         = $self->{id};
   $result{eval_error}  = $eval_error;
   $result{child_error} = $?;
   $result{os_error}    = int $!;

   return \%result;

}


sub execute_module_method {
   my ($self, $params, @argv ) = @_;
   my $method = $params->{method} or croak "method missing";
   my $wantarray = $params->{wantarray};


   my ($p, $m) = $method =~ /^(.*)::(.*)$/;


   unless( $p eq $self->{module}{name} ){
      die "illegal module name $p, did you mean $self->{module}{name}? The requested method was $method";
   }
   unless( $method = $self->{object}->can($m) ){
      die "$p does not support $m"
   }

   unless( $self->{acl}->check({
         user => $ENV{REMOTE_USER},
         module => $p,
         method => $m,
         subjectAltNames => $ENV{subjectAltNames}
         }) ){
         die "$ENV{REMOTE_USER} is not allowed to execute $p::$m";
   }
   debug("running ${p}::${m}");

   return $wantarray
      ? [ $method->($self->{object}, @argv) ]
      : scalar( $method->($self->{object}, @argv) )
}

sub execute_special_method {
   my( $self, $params,@argv ) = @_;
   my $action = $params->{action};
   my $module = $params->{module};


   #todo for the sake of it we assume the if someone uses a module he will also call new to it
   #its anyway teh ony thing the default client does and should do
   unless( $self->{acl}->check({
            user => $ENV{REMOTE_USER},
            module => $module,
            method => 'new',
            subjectAltNames => $ENV{subjectAltNames}
            }) ){
         die "$ENV{REMOTE_USER} is not allowed to use $module";
   }
   $self->check_for_valid_module({
      inc => [
               split(/:/, $self->{conf}->get("global:module_path")),
             dirname(map_to_file(__PACKAGE__)). "/Modules",
      ],
      module => $module,
   });
   if( $self->{object} ){
      die "the connection is already initialized ... please create a new one";
   }

   if ($action eq "use") {
      my $module = $module || "maintenance";
      unless( $module =~ /^[\w_]+$/ ){
        die "illegal module name $module";
      }

      # we use the configured module_path and
      # a built in path (there we'll find 'maintenance.pm' etc
      $self->{module}{inc} = [ split(/:/,
                                     $self->{conf}
                                        ->get("global:module_path")
                               ),
                               dirname(map_to_file(__PACKAGE__))
                                  . "/Modules",
                               @INC
      ];
      $self->{module}{name} = $module;
      $self->{module}{cwd}  = getcwd();
      {
         local @INC = @{ $self->{module}{inc} };
         require $module.'.pm';
      }

   }elsif ($action eq "new") {

      my $call = \&{ $module . "::new" };
      $self->{object} = $call->($module, @argv);
   }else{
      die "unsupported control method";
   }
}

sub check_for_valid_module {
   my( $self, $params ) = @_;
   my $inc = $params->{inc};
   my $module = $params->{module};

   unless( $self->{allowed_modules} ){
      my @allowed_modules;
      for my $include_dir ( @$inc ){
         opendir(my $dh, $include_dir) or next;
         push @allowed_modules,  grep { $_ !~ /^\./ && -f "$include_dir/$_" } readdir($dh);
         closedir $dh;
      }
      debug( "allowed modules". join(",", @allowed_modules)."  in directories: ".join(",", @$inc) );
      @allowed_modules =  map{ my $mod = $_; $mod =~ s/\..*$//; $mod } @allowed_modules;
      $self->{allowed_modules} = { map { $_ => $_ } @allowed_modules };
   }
   die "module not installed $module" unless $self->{allowed_modules}{$module};
}

1;
__END__

=head1 NAME

Session

=head1 SYNOPSIS

   use OASIS::Session Store => "/tmp/sessions", MaxAge => 86400;

   # create a new Session
   $session = new Session({ id   => $id, 
                            conf => $conf });
   $id = $session->id();
   $rc = $session->execute({ method => "test::hallo", argv => $argv });


=head1 DESCRIPTION

This modules contains the OASIS session management. According a provided
session id some old session will get resurrected.  If no session id is
known, a new session gets started.

Additionally the module takes care about executing perl code in the
session environment.

=head1 METHODS

=over

=item CONTRUCTOR new(I<...>)

The constructor C<new()> creates a new session or continues an old one.

   my $session = new OASIS::Session;

among the computers on our planet.

If a session id gets passed

   my $session = new OASIS::Session({id => $id});

the session gets restored from a formerly saved status file.
B<NOTE:> Currently the commands gets executed in the current environment
(context of the server!).

The following parameters are accepted in 

=over

=item $id

Scalar, containing the session id.

=item $conf

C<OASIS::Config> object. From this object we're using
C<session:max_age>, C<session:dir>, and C<session:cleanup_interval>.

=back

=item id( )

Returns the current session id (you should expect a B<string>).

=item save( )

Saves the current session data into some file. See L<Session data> for
information about the information we save.  The session file gets opened
in the constructor.  Thus we're independend of uid and directory
changes, since the session keeps the B<file handle> for saving and
restoring. If there is some error during the write operation, the
C<save()> will complain via C<croak()>.

=item execute(I<...>)

Executes some perl function in the current session context. B<...>
should be a HASHREF containing at least the following keys

   method      name of the method to call (fully qualified)
   argv	       reference to the list of arguments (\@_)
   wantarray   context information (true|false)

And it returns a HASHREF containing the following fields

   retval      return value (ARRAY REF if wantarray, SCALAR else)
   eval_error  $@
   child_error $?
   os_error    int $!

   cwd	       current directory (do we need it?)
   uid	       current user id (do we need it?)
   user	       current user name (do we need it?)
   gid	       current group id(s) (do we need it?)
   group       current primary group name (do we need it?)


=back

=head1 Session data

If the sessions restarts the used module has to be loaded again.  For
this to work we need some information:

   module name the name of the loaded module
   module inc  the INC path at module load time
   module cwd  the current dir at module load time

Additional information for proper restoring the old state is saved:

   cwd	       the current directory (where execution stopped)
   object      the object created

=head1 Cleanup

The session directory fills, of course. From time to time old session
files will be deleted from a fork()ed process. The interval and the
maximum age are configurable.

=head1 CONFIG

Via the C<OASIS::Config> we use the following items:

=over

=item session:dir

The directory for saving/storing the sessions.

=item session:max_age

The maximum age for saved session data.

=item session:cleanup_interval

The interval for cleaning (but a Session has to be started to 
start the cleanup).

=back


=head1 STATUS

   API: stable
   Doc: stable, but to be revised

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm: