package demo;

# $Id: demo.pm 3296 2007-09-26 22:01:10Z heiko $
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Modules/demo.pm $
use strict;
use warnings;

sub new {
   my $class = shift;
   $class = ref $class if ref $class;
   return bless {params => \@_}, $class;
}

sub set_name {
   my $self = shift;
   $self->{names} = [@_];

}

sub add_name {
   my $self = shift;

   # my $x = $self->get_names;
   my $x = demo::get_names($self);
   push @{ $self->{names} }, @_;
}

sub get_names {
   my $self = shift;

   return @{ $self->{names} } if wantarray;
   return "SCALAR: " . @{ $self->{names} };
}

sub say_hallo {
   my $self = shift;
   my @r;
   foreach (@{ $self->{names} }) {
      push @r, "Hallo $_\n";
   }
   return @r;
}

sub get_module_args {
   my $self = shift;
   return $self->{params};
}

sub hi {
   my $self = shift;
   return sprintf "HI (%02d), ich bin das DEMO-Modul!\n", $self->{hi}++;
}

sub _scalar    { "a" }
sub _array     { (qw(a b c)) }
sub _array_ref { [qw(a b c)] }
sub _hash      { (a => "A", b => "B", c => "C") }
sub _hash_ref  { { a => "A", b => "B", c => "C" } }

1;

__END__

=head1 NAME

demo - demo module for OASIS

=head1 SYNOPSIS

    use demo;

=cut
# vim:sts=3 sw=3 aw ai sm:
