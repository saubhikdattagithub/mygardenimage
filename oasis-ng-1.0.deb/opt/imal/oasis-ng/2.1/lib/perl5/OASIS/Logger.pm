package OASIS::Logger;

# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Logger.pm $
# $Id$

use strict;
use warnings;
use base qw(Exporter);
our @EXPORT_OK = qw(logger);

use File::Basename;
use File::Spec::Functions qw(abs2rel);
use English qw(-no_match_vars);
use Term::ANSIColor qw(:constants);
use Readonly;

use OASIS::Tools qw(:all);
use base ("OASIS::Logger::$OS_CLASS");

our $VERSION = (split " ", q$Rev: 3419 $)[1];
our @EXPORT = qw(
   &logger
   &log_verbosity
   &emerg &alert &crit &err &warning &notice &info &debug
   &EMERG &ALERT &CRIT
   &ERR &WARNING &NOTICE
   &INFO &DEBUG &NONE
);

use constant NONE    => \0;
use constant EMERG   => \1;
use constant ALERT   => \2;
use constant CRIT    => \3;
use constant ERR     => \4;
use constant WARNING => \5;
use constant NOTICE  => \6;    # <-- default
use constant INFO    => \7;
use constant DEBUG   => \8;

$ENV{ANSI_COLORS_DISABLED} = 1 if !-t STDERR or not exists $ENV{TERM};

# little magic to avoid the warning (see: strict(3perl) /AUTOLOAD/)

my $Verbosity
   = exists $ENV{OASIS_VERBOSITY}
   ? &{ \&{ uc $ENV{OASIS_VERBOSITY} } }
   : NOTICE;

sub import {
   my $self = shift;

   # find SIG in @_ and remove it
   @_ = map {
      $_ eq "SIG" and do {
         $SIG{__DIE__} = sub { die @_ if $^S; err (@_); exit 1 };
         $SIG{__WARN__} = sub { warning(@_) };
         ();
      };
      $_;
   } @_;

   $self->export_to_level(1, @_);
   _os_init(@_);
}

sub logger(@) {
   my $level = shift if ref $_[0] eq "SCALAR";
   my @message = @_ ? @_ : "*";
   #print @message,"\n";
   # if there's a level provided, than it's up to the
   # syslog module to handle the logging request
   if (defined $level) {
      return if $$level > $$Verbosity;
      return
           $level == EMERG   ? _os_log(LOG_EMERG,   @message)
         : $level == ALERT   ? _os_log(LOG_ALERT,   @message)
         : $level == CRIT    ? _os_log(LOG_CRIT,    @message)
         : $level == ERR     ? _os_log(LOG_ERR,     @message)
         : $level == WARNING ? _os_log(LOG_WARNING, @message)
         : $level == NOTICE  ? _os_log(LOG_NOTICE,  @message)
         : $level == INFO    ? _os_log(LOG_INFO,    @message)
         : $level == DEBUG   ? _os_log(LOG_DEBUG,   @message)
         :                     die "internal error";

   }

   # no level was provided: we will not mess with syslog
   # and assume the default NOTICE level
   # IFF some output is printed, depends on the logger_level
   # we set.
   $level = NOTICE;
   return if $$level > $$Verbosity;

   my ($file, $line) = (caller 0)[ 1 .. 2 ];
   my $sub = (caller 1)[3] || "";
   my $pid = sprintf "[%5d]", $$;

   $file = abs2rel $file;

   print STDERR BOLD . "$pid:$file:$line $sub()" . RESET . ": ", @message,
      "\n";
}

sub log_verbosity(;$) {
   return $Verbosity if not defined $_[0];
   return ($Verbosity, $Verbosity = shift)[0];
}

sub emerg(@)   { logger(EMERG,   @_) }
sub alert(@)   { logger(ALERT,   @_) }
sub crit(@)    { logger(CRIT,    @_) }
sub err(@)     { logger(ERR,     @_) }
sub warning(@) { logger(WARNING, @_) }
sub notice(@)  { logger(NOTICE,  @_) }
sub info(@)    { logger(INFO,    @_) }
sub debug(@)   { logger(DEBUG,   @_) }

1;
__END__

=head1 NAME

OASIS::Logger - logging utility functions

=head1 SYNOPSIS

   use OASIS::Logger;

   log_verbosity(NOTICE);

   logger("Hi, I'm here and not there!");
   logger(EMERG, "CPU is on fire!");

   warning("You're warned!");

=head1 DESCRIPTION

Some simple logging function(s).  On Unix the C<syslog> interface is
used, on Windows the C<event log>.

=head1 FUNCTIONS

=over

=item log_verbosity( )

Returns the current log level. Do not expect some human readable result.
You'll get some internal representation of the current log level. The
most useful you can do with it, is to pass it back to C<log_verbosity()>.

=item log_verbosity(I<level>)

This sets the new log level and returns the old one.  Messages equal or more
important than the new level are logged. If you set it to C<DEBUG> you
should expect a lot messages.

The default level (hardcoded) is B<NOTICE>.

The levels are according the functions mentioned below (in order of
verbosity: DEBUG, INFO, NOTICE, WARNING, ERR, CRIT, ALERT, EMERG).
One special level C<NONE> exists, if this is used, nothing gets logged.

=item logger(I<LIST>)

Print I<LIST> to STDERR. If the list is empty, just print "*". The
output is prefixed with the PID of the printing process. The implicit
verbosity level is C<NOTICE>.  If the verbosity level is less, nothing
gets printed!

=item logger(I<level>, I<LIST>)

This is the generic logging function. All other functions are mapped to
this one.

=back

=head2 level functions

=over

=item emerg(I<< LIST >>) - system is unusable

Example: System was(!) on fire.

=item alert(I<< LIST >>) - action must be taken immediatly

Example: System is burning already.

=item crit(I<< LIST >>) - critical condition

Example: Hard disks have high temperature.

=item err(I<< LIST >>) - error condition

Example: Temperature sensor tells minus 300 Celsius.

=item warning(I<< LIST >>) - warning condition

Example: Temperature sensor doesn't work.

=item notice(I<< LIST >>) - normal, but significant, condition

Example: Temperature sensor activated.

=item info(I<< LIST >>) - informational message

Example: Temperature sensor module version 0.2

=item debug(I<< LIST >>) - debug level message

Example: anything else

=back

=head1 ENVIRONMENT

You may set C<OASIS_VERBOSITY> so some of the above levels, it will
override any level set in the program code.

=head1 STATUS

   API:	 stable
   DOC:	 stable

=head1 AUTHOR

Marcus Obst <mobst@schlittermann.de> and Heiko Schlittermann
<hs@schlittermann.de>

=head1 SEE ALSO

L<logger>(1), L<syslog>(3), L<syslogd>(8), L<Smart::Comments>(3perl)

=for :vim
# vim:sts=3 sw=3 aw ai sm:
end
