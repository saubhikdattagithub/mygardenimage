package OASIS::Message;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
# $Id$
# $URL: /local/sapsi/branch/ng/oasis/scratch/message.pm $

use 5.8.0;
our $VERSION = (split " ", q$Rev: 3419 $)[1];

use strict;
use warnings;
use Carp;

use Readonly;

use OASIS::Logger;
use OASIS::Message::request;
use OASIS::Message::response;
use IO::Select;
use OASIS::Serializer::JSON;
use Data::Dumper;

use if $ENV{DEBUG} => "Smart::Comments";

Readonly my $PROTOCOL => "MESSAGE FORMAT 2";

our %supported_serializers = (
   JSON => 'OASIS::Serializer::JSON',
);

use Class::Struct HEADER => { content_serializer => '$',
                              content_length     => '$',
};

sub new {
   my $class = shift;
   $class = ref $class if ref $class;

   my $argv = shift;

   if ($argv->{stream}) {

      # construct from stream (receive)
      return $class->read($argv->{stream});
   }

   $argv->{serializer} ||= OASIS::Serializer::JSON->new;

   my $header = HEADER->new;
   $header->content_serializer($argv->{serializer}->name);

   my $self = { serializer => $argv->{serializer},
                header     => $header,
                body       => undef,
   };

   return bless $self, $class;
}

sub body     { shift->{body} }
sub header   { shift->{header} }
sub protocol { $PROTOCOL }

sub serialized {
   my $self       = shift;
   my $serializer = $self->{serializer};

   my $data = eval{ $serializer->serialize($self->body) };
   if( my $serializer_error = $@ ){
      $data = "unable to serialize message ".Data::Dumper::Dumper($self->body)."$serializer_error";
   }

   debug("sending @{[length $data]} bytes");

   return <<_END, $data;
Content-Serializer: @{[$self->header->content_serializer]}
Content-Length: @{[length $data]}

_END

}

sub write {
   my $self = shift;
   my $s = shift || \*STDOUT;
   $s->print($self->protocol(), "\n", $self->serialized());

}

sub read_header {
   my ($self, $fh) = @_;

   my %header;

   #check for timeout;
   my $select = IO::Select->new( $fh );
   my $start = time;
   while(not $select->can_read(84000) ){
      next if (time - $start) < 80000;
      die "timeout ( 1 day ) while waiting for message";
   }

   # collect the header fields (until we find an empty line
   my $line;
   while (defined($line = $fh->getline()) && $line !~ /^\s*$/) {
      $line =~ s/\s*$//;
      my ($k, $v) = (split /:\s*/, $line, 2);
      $k =~ s/-/_/g;    # to make it Class::Struct conform
      $header{ lc $k } = $v;
   }
   unless( defined $line ){
      my $peer_addr = eval{ $fh->PeerAddr } || '';
      confess "Empty message recieved from server ".$peer_addr;
   }
   $self->{header} = new HEADER %header;
}

sub read {
   my ($class, $fh) = @_;
   my $self = {};

   ### assert: !ref($class)

   # if not called as object method but as class method
   bless $self, $class;
   $self->read_header($fh);

   croak "No serializer!" unless defined $self->header->content_serializer();

   my ($serializer, $version) = split " ", $self->header->content_serializer();

   # the string unsupported serializer is important for the client to retry with different one and know 
   # that it hasnt been executed yet so seave this alone or also adapt in OASIS.pm!
   my $serialiser_class = $supported_serializers{$serializer} 
      or die "unsupported serializer in message";
   my $serialiser_file  = $serialiser_class.'.pm';
   $serialiser_file =~ s/::/\//g;
   require $serialiser_file;
   $serialiser_class->import();
   $self->{serializer} = $serialiser_class->new;


   $self->{body} = $self->{serializer}
      ->read({ stream => $fh, length => $self->header->content_length });

   return $self;
}

1;
__END__

=head1 NAME

message -- base class for OASIS rpc messages

=head1 SYNOPSIS

   use message;

   # generate from real data
   $message = new Message ({ 
         type => $type,                          # REQUEST|RESPONSE
         data => \%DATA,
         serializer => new OASIS::Serializer::storable, # optional
   });

   # reconstruct from stream
   $message = new Message ({
         stream => \*STDIN
   });

   # save to stream
   $message->write(\*STDOUT);

   # access the data
   $header = $data->header();
   $body   = $data->body();


=head1 DESCRIPTION

This is the base class for L<message::request> and L<message::response>,
it is responsible for creating the right message format, for serialization
and deserialization.

=head1 CONTRUCTOR

=over

=item new { data => I<DATA> }

=item new { stream => I<STREAM> }

=item new { stream => I<STREAM>, serializer => I<SERIALIZER> }

Creates a new message. The first form gets passed the data portion of
the message The second form tries to read the stream and to recreate the
message from this stream.

If you pass a serializer, it has to be a subclass of L<serializer>.

=back

=head1 METHODS

=over

=item body()

Returns the body of the message.  Basically it's the hash passed as the
data.

=item header()

Returns the header of the message.  B<Note:> Some header fields (esp.
"Content-Serializer" can't be set at this time.

=item message()

Returns the complete message (that is header + body, but not any
additional information (as the serializer attribute et. al.).

=item write([I<HANDLE>])

The C<print()> sends the B<serialized> data to the given file handle.
In absence of this handle we'll send to C<STDOUT>.

=item read([I<HANDLE>])

Read a message from the given handle (default: C<STDIN>).

=item serialized()

This returns the serialized version (string) of the message, normally
consisting of header and body.

=back

=head1 SEE ALSO

L<message::request>, L<message::response>, L<serializer>

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm:
