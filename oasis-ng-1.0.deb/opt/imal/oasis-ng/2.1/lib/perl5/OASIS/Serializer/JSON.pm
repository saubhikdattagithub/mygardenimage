package OASIS::Serializer::JSON;
use strict;
use warnings;
use base qw(OASIS::Serializer);

use JSON::XS;
use Carp;
use Data::Dumper;

sub new {
   my $class = shift;
   $class = ref $class if ref $class;

   my $self = { name        => "JSON",
                serialize   => sub{
                   return eval{
                      JSON::XS->new->convert_blessed(1)->utf8->encode(@_)
                   } || confess $@.Dumper(@_);
                },
                deserialize => sub{
                   return eval {
                      JSON::XS->new->convert_blessed(1)->utf8->decode(@_)
                   } || confess $@.Dumper(@_);

                },
   };

   bless $self, $class;
}
1;
