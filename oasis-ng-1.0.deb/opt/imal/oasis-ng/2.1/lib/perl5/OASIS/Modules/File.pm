package File;

# $Id: File.pm 3419 2007-10-19 08:53:58Z heiko $
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Modules/File.pm $

use strict;
use warnings;
use IO::File;
use File::Copy;
use File::Find;
use Fcntl ':flock';

#use POSIX;
use Digest::MD5;
use Carp;
use File::Spec::Functions qw/ rel2abs /;

use OASIS::Logger;

our $VERSION = sprintf("%d", q$LastChangedRevision: 3419 $ =~ /(\d+)/);

sub new {
   my $proto = shift;
   my $class = ref($proto) || $proto;
   bless {}, $class;
}

sub register { carp "depreciated @{[(caller 0)[3]]}"; 1 }
sub Register { carp "please use register()";          goto &register }

sub Upload {
   my $self = shift;
   my ($fname, $fdata) = $self->_get_params(@_);
   my $fl;

   my $err;

   $self->{debug} and print(" File::Upload: $fname", 1);
   $fname = rel2abs $fname;
   not -e $fname and $fl = 1;
   if ($fl) {
      open FH, "> $fname";
      close FH;
   }
   my $fh = new IO::File ">$fname" or die "Can't open >$fname: $!";
   binmode $fh;
   if (defined $fh) {
      print $fh $fdata or $err .= "File::Upload: print: $!";
      $fh->close;
   }
   else {
      die "$$: File::Upload: failed $!";
   }
   return 1;
}

sub Download {
   my $self = shift;
   my ($fname) = _get_params($self, @_);
   $self->{debug} and print(" File::Download: $fname");
   return _slurp($self, $fname)

}

sub Stat {
   my $self = shift;
   my ($fname) = _get_params($self, @_);

   $self->{debug} and print(" File::Stat: $fname");
   return stat $fname;
}

sub Chmod {
   my $self = shift;
   my ($mode, @fnames) = _get_params($self, @_);
   my $fname;
   for $fname (@fnames) {
      print(" File::Chmod: $mode, @fnames");
      chmod($mode, @fnames) or $@ = \$!;
   }

}

sub Exec {
   my $self = shift;
   my ($fname, $timeout) = $self->_get_params(@_);
   debug("File::Exec: $fname");
   my @ret;
   if (defined($timeout)) {
      eval {
         local $SIG{ALRM} = sub {die "timeout"};
         alarm($timeout);
         @ret = `$fname`;
         alarm(0);
      };
      if ($@ =~ /^timeout/) {
         # Set $? as return value of kill in case of timeout error.
         $? = kill 'TERM', -getpgrp(); # terminate the process group as a whole if timeout reaches.
      }
   }
   else {
      @ret = `$fname`;
   }
   debug("length: ", length(join "", @ret));
   $self->{lastreturncode} = $?;
   @ret;
}

sub GetExecCode {
   my $self = shift;
   return $self->{lastreturncode};
}

sub Copy {
   my $self = shift;
   my ($src_fname, $dst_fname) = _get_params($self, @_);
   print(" File::Copy: $src_fname, $dst_fname");
   copy $src_fname, $dst_fname or return $!;
}

sub Move {
   my $self = shift;
   my ($src_fname, $dst_fname) = _get_params($self, @_);
   if ($self->{debug}) { print(" File::Move: $src_fname, $dst_fname"); }
   if ($self->{force}) {
      print(" File::move: $dst_fname with wrong md5 state");
      die "$$ File is not registered properly";
   }
   move $src_fname, $dst_fname or return $!;
}

sub Remove {
   my $self = shift;
   my ($fname) = _get_params($self, @_);
   $self->{debug} and print(" File::Remove: $fname");
   unlink $fname or return $!;
}

sub _get_params {
   my $self  = shift;
   my $param = shift;
   if (ref $param eq 'HASH') {

      if ($param->{debug}) {
         $self->{debug} = $param->{debug};
         $self->{debug} > 0
            and print(" File::_get_params: debug: $param->{debug}");
      }
      if ($param->{force}) {
         $self->{force} = $param->{force};
         $self->{debug} and $self->{debug} > 0
            and print(" File::_get_params: force: $param->{force}");
      }

   }
   else {
      unshift(@_, $param);
   }
   return @_;
}

sub _slurp {
   my ($self, $fname) = @_;
   if (-e $fname) {
      my $fh = IO::File->new("< $fname")
         or print(" Couldn't open $fname for reading: $!\n");
      my $content;
      binmode $fh;
      read $fh, $content, -s $fh;
      return $content;
   }
   else {
      return undef;
   }
}

1;
__END__

=head1 NAME

File.pm - File module for OASIS

=head1 SYNOPSIS

   my $oasis = OASIS::OASIS->new($host) or die $!;
   my $f = $oasis->File or warn $!;
   $f->Upload( {force => 'Yes'}, "c:/Temp/Hello.bat", "echo Hallo das ist ein Script" );
   print join ( "\n", $f->Search( {debug => 'Yes'}, {regex => '\.bat'}, 'C:/Temp' ) ) or warn $!;
   $f->Copy( { debug => 'Yes' }, "c:/Temp/Hello.bat", "c:/Temp/Bello.bat" );
   print $f->Exec( "c:/Temp/Bello.bat" );

=head1 METHODS

=head2 $file->Upload($fname, $data)

     This method will upload a file , whith the contend $data, to the location
     specified by $fname to the server

=head2 $file->Download(fname);

     This method return the contend of a file specified by its name

=head2 $file->Chmod(mode , @fnames);

      This method sets the attributes of the files, specified in the array @fnames, to mode

=head2 $file->Exec($command);

      This method Excecutes a $command on the server

=head2 $file->Copy(src_fname, dst_fname);

      This method copies a File from src_fname to dst_fname

=head2 $file->Move(src_fname, dst_fname);

      This method moves a file on the server from src_fname to dst_fname

=head2 $file->Remove(fname);

      This method deletes the file, gives by its name, from the server

=cut
