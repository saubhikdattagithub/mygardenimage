package OASIS::Process::Unix;

use 5.8.0;
our $VERSION = (split " ", q$Rev: 122 $)[1];

use strict;
use warnings;
use Carp;

use OASIS::Logger;

use POSIX ":sys_wait_h";

sub new {
   my $class = shift;
   my $self  = {};
   $self->{cmd} = shift or croak "No command line given!";

   return bless $self, $class;
}

sub start {
   my $self = shift;
   return 1 if $self->isRunning();

   my $pid = fork();
   if (not defined $pid) {
      carp "Cannot fork new process: $!";
      return undef;
   }

   if ($pid == 0) {    # --- child
      exec($self->{cmd}) or carp "Cannot exec new process: $!";
      exit 1;
   }

   # --- parent
   logger(DEBUG, "$self->{cmd} running!");
   $self->{pid} = $pid;
   return 1;
}

sub stop {
   my $self = shift;

   return 1 unless $self->isRunning();

   kill TERM => $self->{pid};
   eval {
      local $SIG{ALRM} = sub { die "TIMEOUT" };
      alarm(3);
      wait();
      alarm(0);
   };

   if ($@ =~ /^TIMEOUT/) {
      kill KILL => $self->{pid};
      wait();
   }
   elsif ($@) {
      die $@;
   }

   delete $self->{pid};

   logger(DEBUG, "$self->{cmd} stopped!");
}

sub isRunning {
   my $self = shift;

   return 0 unless defined $self->{pid};

   #
   # is child gone since last status check?
   #
   while ((my $pid = waitpid(-1, WNOHANG)) > 0) {
      if ($pid == $self->{pid}) {    # child gone away
         delete $self->{pid};
         return 0;
      }
   }

   #
   # send pseudo signal to process
   #
   return 1 if (kill 0 => $self->{pid});
   return 0;
}

1;
__END__

=head1 NAME

Process::Unix -- spawn detached processes under unix

=head1 SYNOPSIS

   use Process;

   my $p1 = new Process("/usr/bin/process");

   $p1->start();
   $p1->stop();
   $p1->isRunning();

=head1 DESCRIPTION
   
   Handle creation of processes under unix and windows.

=head1 METHODS

=over

=item 

=back

=head1 AUTHOR

Marcus Obst <mobst@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm:
