# © 2007 Heiko Schlittermann <hs@schlittermann.de>
#	 Marcus Obst <mobst@schlittermann.de>
#
# $Id$
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Protocol/proxy.pm $

package OASIS::Protocol::proxy;

use 5.8.0;

use Carp;
use strict;
use warnings;
use Socket;
use IO::Socket::INET;
use IO::Select;

use if $ENV{DEBUG} => "Smart::Comments";
use Readonly;

use OASIS::Logger;
use OASIS::Protocol;

sub new($) {
   my $class = ref $_[0] ? ref shift : shift;
   my $arg = shift or croak "expected arg hash";

   return bless {
      conf => $arg->{conf},
      connect_timeout => 26, # the timeout for initial connection can be short, rather retry than wait too long
      timeout => 84500, # less than one day to give client some time to wait for error message
   }, $class;
}

sub _feed_peers {
   my $self = shift;
   my $s    = IO::Select->new();

   my @peers = @{$self}{qw(client next_peer)};

   my %name = ($self->{client}    => "CLIENT",
               $self->{next_peer} => "NEXT");

   my %recipient = (@peers, reverse @peers);
   $s->add(@peers);

   my $next_hop_verified = 0;

   LOOP: while ($s->count()) {

      # wait for input on some of our channels
      my @ready = $s->can_read($self->{timeout});
      #timeout fo 1 day to avoid hanging processes if something wicked happenes with the connection
      unless(@ready){
         debug("proxy socket closed after select timeout of $self->{timeout}s");
         last LOOP;
      }
      SOCKET: foreach my $socket (@ready) {

         my $buffer;
         my $r = $socket->sysread($buffer, 1024 * 8);

         #happens also from normal disconnect
         if (not defined $r) {    # error
            debug("read error from $name{$socket}");
            last LOOP;
         }

         if( not($next_hop_verified) and $socket eq $self->{next_peer} ){
            unless( $buffer =~ /^OASIS/ ){
               print { $self->{client} } "$name{$socket} could not be verified as oasis";
               debug("$name{$socket} could not be verified as oasis ".$buffer);
               last LOOP;
            }else{
               debug("verified $name{$socket} as oasis");
               $next_hop_verified = 1;
            }
         }

         if ($r) {
            #debug(sprintf "%4d bytes from " . "$name{$socket} " . "to $name{$recipient{$socket}}", $r);
            $recipient{$socket}->syswrite($buffer);
            next SOCKET;
         }

         # if ($r == 0)
         debug(  "transmission from $name{$socket} "
               . "to $name{$recipient{$socket}} shut down");
         $s->remove($socket);
         $recipient{$socket}->shutdown(1);
      }
   }

   debug("closing and leaving proxy loop");
   foreach (@peers) { $_->close() }
}

sub serve() {
   my $self = shift;
   $self->{client} = shift;
   my $first_line = shift;

   return 0 if $first_line !~ /^OASIS CONNECT (.+)/;

   debug("protocol: proxy [$first_line]");
   my ($neighbour_host, @remote_hosts) = split(/\s*\|\s*/, $1);

   debug("neighbour = $neighbour_host");
   debug("remaining proxies = @remote_hosts");
   my( $next_host, $next_port ) = split /:/, $neighbour_host;
   unless( $next_port =~/^\d+$/ ){
      die "next port is no number";
   }

   #
   # make connection to next peer
   #

   $self->{next_peer} = new IO::Socket::INET(PeerAddr => $neighbour_host, Timeout => $self->{connect_timeout});


   my $connection_error = '';
   unless( $self->{next_peer} ){
      $connection_error = "Cannot connect to neighbour host $neighbour_host: $!";
   }

   #
   # did we hit the final destination ore are there some other clients
   #
   unless( $self->check({ client => $self->{client}, neighbour_host => $neighbour_host, next_peer => $self->{next_peer} }) ){
      print { $self->{client} } "Connection forbidden to $neighbour_host";
      croak "connection forbidden to $neighbour_host"
   }

   unless( $self->{next_peer} ){
      print { $self->{client} } $connection_error;
      debug $connection_error;
      croak $connection_error;
   }

   if (not @remote_hosts) {    # directly connected
      print { $self->{client} } "OASIS CONNECTED\n";
      debug("direct connection");
   }
   else {                      # still some intermediate proxies
      print { $self->{next_peer} } "OASIS CONNECT "
         . join(" | ", @remote_hosts), "\n";
      debug("indirect connection");
   }

   use Socket;
   setsockopt( $self->{next_peer}, SOL_SOCKET, SO_KEEPALIVE, 1);
   $self->{next_peer}->timeout($self->{timeout});

   $self->_feed_peers();

   return 1;
}

sub check{
   my( $self, $params ) = @_;
   $params ||= {};
   my $client   = $params->{client} or croak "source parameter missing";
   my $next_peer= $params->{next_peer};
   my $neighbour_host   = $params->{neighbour_host}  or croak "neighbour_host parameter missing";

   #check if neighbourhost is a ip;
   my $neighbour_host_type = 'DNS';
   my ( $ip, $port ) = split (/:/,$neighbour_host);
   $port ||= 8086;
   if( $ip ){
      my @tupels = grep(/^\d+$/, split(/\./,$ip)); # filter out non-numeric values
      if( @tupels == 4
         and $tupels[0] <= 255
         and $tupels[1] <= 255
         and $tupels[2] <= 255
         and $tupels[3] <= 255
         and $port =~/^\d+$/
         ){
         $neighbour_host_type = 'IP';
      }
   }

   #the client doesnt tell us his address and we cant trust him anyways so we
   #rely on the network stack
   my ($source_ip, $source_port ) = ( $client->peerhost, $client->peerport);
   my $source_hostname = gethostbyaddr( $client->peeraddr,AF_INET);


   #for the target the connection stack seem sto be a bit shaky sometime so we
   #fall back to the clients information, we connected there anyways
   my ($next_peer_ip, $next_peer_port, $next_peer_hostname) = ('','','');

   if( $next_peer ){
      ($next_peer_ip, $next_peer_port ) = ( $next_peer->peerhost, $next_peer->peerport);
      $next_peer_hostname = gethostbyaddr( $next_peer->peeraddr,AF_INET);
   }

   if(  $neighbour_host_type eq 'IP' ){
      $next_peer_ip ||= $ip;
   }else{#DNS
      $next_peer_hostname ||= $ip; # i know but look up that ok
   }

   $next_peer_port ||= $port;

   $next_peer_ip .= ':'.$next_peer_port;
   $next_peer_hostname .= ':'.$next_peer_port;
   $source_ip .= ':'.$source_port;
   $source_hostname .= ':'.$source_port;

   for my $acl ( $self->parsed_config ){
      my $source   = $acl->{source};
      my $target   = $acl->{target};
      my $access   = $acl->{access};
      my $type     = $acl->{type};

      my $target_matched = 0;
      my $source_matched = 0;
      debug( "trying rule $source $target $access");
      if( ( $type eq 'ALL' or $type eq 'IP') and $source_ip =~ /$source/i ){
         $source_matched = $source_ip;

      }elsif( ( $type eq 'ALL' or $type eq 'DNS') and $source_hostname =~ /$source/i ){
         $source_matched = $source_hostname;
      }

      #to check for error messages on connection errors we sometimes have to check without having a
      #standing connection to the next peer
      if( $next_peer ){
         if( ($type eq 'ALL' or $type eq 'IP') and  $next_peer_ip =~ /$target/i){
            $target_matched = $next_peer_ip;
         }elsif( ( $type eq 'ALL' or $type eq 'DNS') and $next_peer_hostname =~ /$target/i){
            $target_matched = $next_peer_hostname;
         }
      }

      if(not $target_matched
         and  (
		$type eq $neighbour_host_type
              or $type eq 'ALL'
              )
         and $neighbour_host =~ /$target/i){
         $target_matched = $neighbour_host;
      }

      if( $source_matched and $target_matched ){
         info("proxy: $source_ip( $source_hostname ) to $next_peer_ip( $next_peer_hostname ) == $source $target $type $access");
         if( $access eq '+' ){
            return 1
         }else{
            return
         }
      }
   }
   info("proxy: $source_ip( $source_hostname ) to $next_peer_ip( $next_peer_hostname ) allowed because no rule matched");
   return 1;
}

sub parsed_config {
   my( $self ) = @_;
   return @{ $self->{parsed_config} } if $self->{parsed_config};
   my @parsed_config;
   for my $line ( split /\r*\n/, $self->config ){
      $line =~ s/#.+$//;
      $line =~ s/\s+$//;
      $line =~ s/^\s+//;
      next unless $line;
      my @tokens = split /\s+/, $line;

      my ($access,$type);
      if( @tokens == 3 ){
         $type   = 'ALL',
         $access = pop @tokens;
      }elsif(@tokens == 4){
         $type   = pop @tokens;
         $access = pop @tokens;
      }
      #transform each field in a way acb*xyz   to \Qabc\E.*\Qxyz\E
      my $transform_token = sub {
         my( $token ) = @_;
         $token =~ s/\./\./g;
         my @parts = split /\*/, $token;
         return '.*' unless @parts;
         push @parts, '' if $token =~ /\*$/;
         return '^'.join( '.*',  map( {"\Q$_\E"} @parts)).'$';
      };
      @tokens = map { $transform_token->($_) } @tokens;
      my( $source, $target ) = @tokens;

      push @parsed_config, {
         source => $source,
         target => $target,
         access => $access,
         type   => $type,
      };
   }
   $self->{parsed_config} = [@parsed_config];
   return @{ $self->{parsed_config} };
}

sub config_file {
   my( $self ) = @_;
   unless( $self->{config_file} ){
      if( -e $self->etc_dir.'/proxy_acl' ){
         $self->{config_file} = $self->etc_dir.'/proxy_acl';

      }elsif( -e $self->etc_dir.'/default_proxy_acl' ){
         $self->{config_file} = $self->etc_dir.'/default_proxy_acl';

      }elsif( -e $self->etc_dir.'/oasis/proxy_acl' ){
         $self->{config_file} = $self->etc_dir.'/oasis/proxy_acl';

      }elsif( -e $self->etc_dir.'/oasis/default_proxy_acl' ){
         $self->{config_file} = $self->etc_dir.'/oasis/default_proxy_acl';
      }
   }
   return $self->{config_file};
}

sub config {
   my( $self ) = @_;
   unless( $self->{config} ){
      open my $fh , '<', $self->config_file or return '';
      read( $fh, my $buffer , -s $fh );
      $self->{config} = $buffer;
   }
   return $self->{config};
}

sub etc_dir {
   my( $self ) = @_;
   return $self->{etc_dir} if $self->{etc_dir};
   my $dirname = Cwd::realpath( File::Basename::dirname(__FILE__));
   for my $postfix ( '/../','/../../','/../../../','/../../../../'){
      if( -d $dirname.$postfix.'etc/'){
         return $self->{etc_dir} = Cwd::realpath($dirname.$postfix.'etc/');
      }
   }
   return '';
}


1;

__END__

=head1 NAME

server::proxy -- Implement new style proxy protocoll for OASIS

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 METHODS

=over

=item

=back

=head1 SEE ALSO

   server.pm

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

Marcus Obst <mobst@schlittermann.de>

=cut

# vim:sts=3 sw=3 aw ai sm:
