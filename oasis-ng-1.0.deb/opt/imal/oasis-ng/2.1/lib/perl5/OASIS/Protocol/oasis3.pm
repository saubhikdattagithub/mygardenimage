package OASIS::Protocol::oasis3;

# © 2007 Heiko Schlittermann <hs@schlittermann.de>
#        Marcus Obst <mobst@schlittermann.de>
#
# $Id$
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Protocol/oasis2.pm $

use 5.8.0;

use Carp;
use strict;
use warnings;
use IO::Socket::SSL;
use File::Spec;
use Carp;

use if $ENV{DEBUG} => "Smart::Comments";
use Readonly;

use OASIS::Logger;
use OASIS::Session;
use OASIS::Message;
use OASIS::Protocol;    # abstract base

sub new {
   my $class = ref $_[0] ? ref shift : shift;
   my $arg = shift;

   return bless {
      conf => $arg->{conf},
      connect_timeout => 26, # the timeout for initial connection can be short, rather retry than wait too long
   }, $class;
}

# Hier wird der normale Socket für ein SSL-Upgrade vorbereitet!
sub _upgrade_to_ssl {
   my $self = shift;
   logger(DEBUG, "start upgrading to SSL socket");

   my $key = $self->{conf}->get("server:ssl_key");
   my $crt = $self->{conf}->get("server:ssl_crt");
   my $ca_crt = $self->{conf}->get("server:ssl_ca_crt");

   logger(DEBUG, "KEY: $key");
   logger(DEBUG, "CRT: $crt");

   my @e = ((-r $key ? () : "$!: $key"), (-r $crt ? () : "$!: $crt"));
   die join "\n", @e if @e;

   # CIEA-4114
   # we want to restrict to TLS 1.2 and higher but some servers do only support up to TLS 1.0
   # as a temporary oslution we create a oasis-ng papckage that restricts the oasis3.pm (server)
   # to TLS 1.2. It is only installed if supported by the os, thus for OASIS.pm (client) we still
   # need to allow TLS 1.0 and TLS 1.1 to be able to reach old servers even if the client
   # supports higher TLS versions. Over the time, all servers will be patched and we can close
   # the gap between client and server. Anyhow, client and server will always agree on the highest
   # version available for both
   my $s_ssl_version = 'SSLv23:!SSLv3:!SSLv2:!TLSv1:!TLSv11';

   $self->{client} =
      IO::Socket::SSL->start_SSL($self->{client},
                                 SSL_server         => 1,
                                 SSL_key_file       => $key,
                                 SSL_cert_file      => $crt,
                                 SSL_ca_file        => $ca_crt,
                                 SSL_startHandshake => 0,
                                 SSL_verify_mode    => 0x01,
                                 SSL_version        => $s_ssl_version,
      ) or die("Can't upgrade socket to SSL".&IO::Socket::SSL::errstr()  );

   return 1;
}

sub serve($$$) {
   my $self = shift;
   $self->{client} = shift;
   my $first_line = shift;
   logger(DEBUG, "protocol: oasis3 at youre serve'is $first_line");
   return 0 if ($first_line !~ m{^START (?:TLS|PLAIN) OASIS/3$});
   logger(DEBUG, "protocol: oasis3 [$first_line]");
   my $remote_addr = $self->{client}->peerhost;

   $0 .= " [serving]";

   $self->_upgrade_to_ssl();    # sends it's own GO AHEAD message
   # before ssl handshake
   # notify client in plain text that our socket is ready for SSL
   # handshake!
   print { $self->{client} } "OASIS GO AHEAD\n";
   # set timeout for accept_SSL
   $self->{client}->accept_SSL({Timeout=>$self->{connect_timeout}}) || die &IO::Socket::SSL::errstr();    # blockiert (?)

   $ENV{issuer}  = $self->{client}->peer_certificate('issuer');
   $ENV{subject} = $self->{client}->peer_certificate('subject');

   die "unknown certificate" unless $ENV{subject};
   my $delimiter = ',=$';
   my ( $remote_user ) = $ENV{subject} =~ /CN=([^$delimiter]+)/;
   $ENV{REMOTE_USER} = $remote_user;

   require JSON::XS;
   $ENV{subjectAltNames} = JSON::XS::encode_json([$self->{client}->peer_certificate('subjectAltNames')]);

   logger(DEBUG, "upgrading to SSL socket finished");

   while (1) {

      local $ENV{REMOTE_USER} = $ENV{REMOTE_USER};
      my $serialzer_class = $OASIS::Message::supported_serializers{JSON};
      my $message = eval{
         my $request      = OASIS::Message::request->new({ stream => $self->{client} });
         my $requested_serializer = $request->header->content_serializer;
         my( $serializer, $version ) = split /\s+/, $requested_serializer;
         $serialzer_class = $OASIS::Message::supported_serializers{ $serializer } or die "unsupported serializer";
         return $request;
      };
      if( my $error = $@ ){
         return 1 if $error =~ /empty message/i;
         $error =~s/.+ at//;
         OASIS::Message::response->new({
            eval_error => $error,
            serializer => $serialzer_class->new,
         })->write( $self->{client} );
         return 1;
      }
      # just to be sure. this is already checked by the message class itself so we dont care to much here

      if (not $self->{session}) {
         $self->{session} =
            OASIS::Session->new({ conf => $self->{conf},
                                 id   => $message->body()->sid()
                               }
            );
      }

      # now EXECUTE whatever they want
      eval{
          my $response = OASIS::Message::response->new({
                                %{
                                   $self->{session}->execute(
                                      { method    => $message->body()->method(),
                                        argv      => $message->body()->argv(),
                                        wantarray => $message->body()->wantarray(),
                                        remote_addr => $remote_addr
                                      })
                                 },
                                 serializer => $serialzer_class->new,
                                });
          debug("sending client response: ".Data::Dumper::Dumper($response));

         $response->write($self->{client});
      };
      if( my $error = $@ ){
         $error =~s/ at.+//ms;
         OASIS::Message::response->new({
            eval_error => $error,
            serializer => $serialzer_class->new,
         })->write( $self->{client} );
         return 1;
      }
   }

   return 1;
}
1;

__END__

=head1 NAME

OASIS::Protocol::oasis3 -- OASIS server class for protocol 3

=head1 SYNOPSIS

   use OASIS::Protocol::oasis3;

=head1 DESCRIPTION

Hier implementieren wir die gesamte Funktionalität für einen OASIS-Server.

=head1 METHODS

=over

=item ...

=item $server->conf(I<config>)

Pass a OASIS::Conf object to this server.

=back

=head1 SEE ALSO

   Server.pm

=head1 AUTHOR

Heiko Schlittermann <hs@schlittermann.de>

Marcus Obst <mobst@schlittermann.de>

=cut
