#$Id$
package OASIS::AccessControlManager;
use strict;
use warnings;
use Carp;
use File::Basename;
use Cwd;
use OASIS::Logger;
use 5.010;

sub new {
   my( $class, $params ) = @_;
   my $self = {};
   bless $self, $class;
   return $self;
}

sub check{
   my( $self, $params ) = @_;
   $params ||= {};
   my $module = $params->{module} or croak "module parameter missing";
   my $method = $params->{method} or croak "method parameter missing";
   my $user   = $params->{user}   or croak "user parameter missing";

   my $ar_subject_alt_names;
   if ($params->{subjectAltNames}) {
      require JSON::XS;
      $ar_subject_alt_names = JSON::XS::decode_json($params->{subjectAltNames});
   }

   for my $acl ( $self->parsed_config ){
      if(    $user =~ /$acl->{user}/i
         and $module =~ /$acl->{module}/i
         and $method =~ /$acl->{method}/i
         )
      {
         debug("ACL: $user $module $method == /$acl->{user}/i /$acl->{module}/i /$acl->{method}/i $acl->{access}");
         if ($acl->{access} eq '-') {
            return;
         }
         # if access is 'certificate' then check that hostname is in subjectAltNames list
         elsif ($acl->{access} eq 'certificate') {
            if (@{$ar_subject_alt_names}) {
               chomp(my $s_local_hostname = `hostname`);
               ($s_local_hostname) = split /\./, $s_local_hostname;
               for my $s_hostname (@{$ar_subject_alt_names}) {
                  return 1 if $s_hostname =~ /^$s_local_hostname$/i;
               }
            }
            return;
         }
         else {
            return 1;
         }
      }
      else {
         debug("ACL: $user $module $method != /$acl->{user}/i /$acl->{module}/i /$acl->{method}/i $acl->{access}");
      }
   }
   debug("ACL allowance because all checks failed");
   return 1;
}

sub parsed_config {
   my( $self ) = @_;
   return @{ $self->{parsed_config} } if $self->{parsed_config};
   my @parsed_config;
   for my $line ( split /\r*\n/, $self->config ){
      $line =~ s/#.+$//;
      $line =~ s/\s+$//;
      $line =~ s/^\s+//;
      next unless $line;
      my @tokens = split /\s+/, $line;

      my $access = pop @tokens;
      next unless $access =~ /[\+-]|certificate/;
      #transform each field in a way acb*xyz   to \Qabc\E.*\Qxyz\E
      my $transform_token = sub {
         my( $token ) = @_;
         my @parts = split /\*/, $token;
         return '.*' unless @parts;
         push @parts, '' if $token =~ /\*$/;
         return '^'.join( '.*', map( {"\Q$_\E"} @parts)).'$';
      };
      @tokens = map { $transform_token->($_) } @tokens;
      my( $user, $module, $method) = @tokens;

      push @parsed_config, {
         user => $user,
         module =>$module,
         method => $method,
         access => $access,
      };
   }
   $self->{parsed_config} = [@parsed_config];
   return @{ $self->{parsed_config} };
}

sub config_file {
   my( $self ) = @_;
   unless( $self->{config_file} ){
      if( -e $self->etc_dir.'/acl' ){
         $self->{config_file} = $self->etc_dir.'/acl';
      }elsif( -e $self->etc_dir.'/default_acl' ){
         $self->{config_file} = $self->etc_dir.'/default_acl';
      }elsif( -e $self->etc_dir.'/oasis/acl' ){
         $self->{config_file} = $self->etc_dir.'/oasis/acl';
      }elsif( -e $self->etc_dir.'/oasis/default_acl' ){
         $self->{config_file} = $self->etc_dir.'/oasis/default_acl';
      }
   }
   return $self->{config_file};
}

sub config {
   my( $self ) = @_;
   unless( $self->{config} ){
      open my $fh , '<', $self->config_file or return '';
      read( $fh, my $buffer , -s $fh );
      $self->{config} = $buffer;
   }
   return $self->{config};
}

sub etc_dir {
   my( $self ) = @_;
   return $self->{etc_dir} if $self->{etc_dir};
   my $dirname = Cwd::realpath( File::Basename::dirname(__FILE__));
   for my $postfix ( '/../','/../../','/../../../','/../../../../'){
      if( -d $dirname.$postfix.'etc/'){
         return $self->{etc_dir} = Cwd::realpath($dirname.$postfix.'etc/');
      }
   }
   return '';
}


1;
