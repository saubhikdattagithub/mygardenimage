package OASIS::Tools;

# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/trunk/lib/OASIS/Tools.pm $
# $Id: Tools.pm 3419 2007-10-19 08:53:58Z heiko $

use strict;
use warnings;
use Exporter;
use Carp;
use English qw(-no_match_vars);
use Readonly;
use OASIS::Logger;

our $VERSION   = (split " ", q$Rev: 3419 $)[1];
our @ISA       = qw/Exporter/;
our @EXPORT_OK = qw/&on_windows $OS_CLASS &touch &create_p_file &map_to_file/;
our %EXPORT_TAGS = (all => \@EXPORT_OK,);

our @CLEAN_FILES = ();

BEGIN {
   use constant on_windows => ($OSNAME =~ /mswin/i);
   Readonly our $OS_CLASS => (($OSNAME =~ /mswin/i) ? "win32" : "unix");
}

#END { unlink @CLEAN_FILES }
END {
   foreach (@CLEAN_FILES) {
      OASIS::Logger::debug("removing $_");
      unlink $_;
   }
}

sub touch($) {
   my ($file) = @_;
   my $fh;
   open($fh, ">$file") or croak "Can't open >$file: $!";
   close($fh);
}

sub create_p_file($$$) {
   my ($file, $content, $create) = @_;
   my $mypid = $$;

   return if not defined $file;
   return if not defined $content;

   if ($create) {
      require File::Basename;
      import File::Basename;

      if (!-d dirname($file)) {
         require File::Path;
         import File::Path;
         mkpath(dirname($file), 0, 0700);
      }
   }

   open(X, ">$file") or die "Can't open $file: $!\n";
   print X "$content\n";
   close(X);

   push @CLEAN_FILES, $file;

}

sub map_to_file($) {
   my $p = shift;
   $p =~ s{::}{/};
   $INC{"$p.pm"};
}

1;
__END__

=head1 NAME

OASIS::Tools - some general utility functions

=head1 SYNOPSIS

   use OASIS::Tools qw($OS_CLASS on_windows);
   use OASIS::Tools qw(:all);

   creaate_p_file("/tmp/x.pid", $$, 1);

=head1 DESCRIPTION

Some small utility functions.  Normally you do not need to know about
them.

=head1 EXPORTED variables

=over

=item B<$OS_CLASS> (r/o)

Contains B<win32> or B<unix>.

=back

=head1 EXPORTED functions

=over

=item on_windows

Returns true or false, depending on the OS.

=item touch(I<file>)

Similiar to L<touch>(1).

=item create_p_file(I<file>, I<content>, I<create_dirs>)

Used to create pid and port file(s) in server.pl and watchdog.pl. But
may be it's of practical use somewhere else too.

=item map_to_file(I<package_name>)

Find the package in C<%INC> (thus it has to be loaded already) and
return the real file name of this package, according to the C<%INC>.

=back

=head1 EXAMPLES

   use OASIS::Tools qw(:all);
   use base ("OASIS::Logger::$OS_CLASS");


=head1 VERSION

   $Id: Tools.pm 3419 2007-10-19 08:53:58Z heiko $

=cut

# vim:sts=3 et sw=3 aw:
