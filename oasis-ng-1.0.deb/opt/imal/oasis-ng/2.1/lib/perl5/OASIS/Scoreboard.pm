package OASIS::Scoreboard;

use 5.8.0;
our $VERSION = (split " ", q$Rev: 122 $)[1];

use strict;
use warnings;
use Carp;

use IO::File;
use IO::Dir;
use File::Path;

use if $ENV{DEBUG} => "Smart::Comments";

use OASIS::Logger;

sub new {
   my $class = shift;
   my $self  = {};
   $self->{directory} = "./run";

   $self->{idleDir} = $self->{directory} . "/idle/";
   $self->{busyDir} = $self->{directory} . "/busy/";

   -d $self->{idleDir} or mkpath $self->{idleDir};
   -d $self->{busyDir} or mkpath $self->{busyDir};

   bless $self, $class;
   return $self;
}

sub idle {
   my $self = shift;
   my $pid = shift || undef;

   if (defined $pid) {
      return 1 if -e "$self->{idleDir}/$pid";
      return 0;
   }

   return
      map { $_ =~ s|^$self->{idleDir}||; $_ } glob($self->{idleDir} . "*");
}

sub busy {
   my $self = shift;
   my $pid = shift || undef;

   if (defined $pid) {
      return 1 if -e "$self->{busyDir}/$pid";
      return 0;
   }

   return map { $_ =~ s|$self->{busyDir}||; $_ } glob($self->{busyDir} . "*");
}

sub markIdle {
   my $self = shift;
   my $pid  = shift;

   logger(DEBUG, "mark $$ busy -> idle");
   if (!rename $self->{busyDir} . "/$pid", $self->{idleDir} . "/$pid") {
      logger(DEBUG, "mark $$ as idle");
      IO::File->new("> @{ [ $self->{idleDir} ] }/$pid")
         or croak "Cannot create idle pid file: $!";
   }
}

sub markBusy {
   my $self = shift;
   my $pid  = shift;

   logger(DEBUG, "mark $$ idle -> busy");
   if (!rename $self->{idleDir} . "/$pid", $self->{busyDir} . "/$pid") {
      logger(DEBUG, "mark $$ as busy");
      IO::File->new("> @{ [ $self->{busyDir} ] }/$pid")
         or croak "Cannot create busy pid file: $!";
   }
}

sub remove {
   my $self = shift;
   my $pid  = shift;

   unlink($self->{idleDir} . "/$pid");
   unlink($self->{busyDir} . "/$pid");
   logger(DEBUG, "Remove $pid from scoreboard");
}

1;
__END__

=head1 NAME

oasis -- the client side module

=head1 SYNOPSIS

   use Scoreboard;

   my $scoreboard = new Scoreboard();

   my @idle_processes = $scoreboard->idle();
   my @busy_processes = $Scoreboard->busy();

   if ($scoreboard->idle($pid)) {
      ...
   }

   $scoreboard->markIdle($$);    # mark process as idle
   $scoreboard->markBusy($$);    # mark process as busy

   $scoreboard->remove($$);      # remove process from scoreboard

=head1 DESCRIPTION

Bla

=head1 METHODS

Bla

=over

=item Foo

=back

=cut

# vim:sts=3 sw=3 aw ai sm:
