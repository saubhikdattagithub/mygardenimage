package OASIS;

# $Id$
# $URL: https://svn.schlittermann.de/sapsi/oasis-ng/tags/r0.927/lib/OASIS.pm $

our $VERSION = "2.1";

use 5.8.0;

use strict;
use warnings;
use Carp;
use IO::Socket::INET;
use IO::Socket::SSL 1.06;

use Hash::Util qw(lock_keys);

use Fatal qw(:void open);

use if $ENV{DEBUG} => "Smart::Comments";

# should we use qw(SIG) on the server?
use OASIS::Logger;
use OASIS::Server;
use OASIS::Message;

sub new {
   my $class = shift;
   $class = ref $class if ref $class;

   my ( $default_key, $default_ca, $default_cert );
   if ( $^O =~ /mswin/i ) {
      $default_key  = 'c:\opt\imal\oasis-ng\current\etc\oasis\ssl\oasis_non_gmp.key';
      $default_cert = 'c:\opt\imal\oasis-ng\current\etc\oasis\ssl\oasis_non_gmp.cer';
      $default_ca   = 'c:\opt\imal\oasis-ng\current\etc\oasis\ssl\ca_bundle.cer';

   } else {
      $default_key  = '/opt/imal/oasis-ng/current/etc/oasis/ssl/oasis_non_gmp.key';
      $default_cert = '/opt/imal/oasis-ng/current/etc/oasis/ssl/oasis_non_gmp.cer';
      $default_ca   = '/opt/imal/oasis-ng/current/etc/oasis/ssl/ca_bundle.cer';
   }

   my $self = {
      default_port     => 8086,
      service          => undef,
      host             => "localhost",
      force_tls        => undef,
      socket           => undef,
      sid              => undef,
      test_server_pid  => undef,
      test_server_conf => undef,           # FH, for unlink
      certfile         => $default_cert,
      keyfile          => $default_key,
      ca_file          => $default_ca,
      timeout          => 84600, # one day to wait for oasis call to finish, want to catch the condition before the proxy closes the connection
      connect_timeout  => 28, # timeout for initial connection, want to catch error from proxy first
   };
   bless $self, $class;
   lock_keys(%$self);

   # process module arguments, they come as a hashref
   croak "first argument should be a hashref"
       if not ref $_[0] eq "HASH";

   my $argv = shift;

   # find some "service" or "use" argument
   foreach ( keys %$argv ) {
      /^service|use$/ and $self->{service} = delete $argv->{$_};
   }

   # for historical reasons this parameter is called /port/ and not
   # /default_port/ :-( // .hs
   $self->{default_port}    = delete $argv->{port} if exists $argv->{port};
   $self->{host}            = delete $argv->{host} if exists $argv->{host};
   $self->{certfile}        = delete $argv->{certfile} if exists $argv->{certfile};
   $self->{keyfile}         = delete $argv->{keyfile} if exists $argv->{keyfile};
   $self->{ca_file}         = delete $argv->{ca_file} if exists $argv->{ca_file};
   $self->{timeout}         = delete $argv->{timeout} if exists $argv->{timeout};
   $self->{connect_timeout} = delete $argv->{connect_timeout} if exists $argv->{connect_timeout};
   $self->{force_tls}       = delete $argv->{force_tls}
       if exists $argv->{force_tls};

   if (%$argv) {
      croak "unknown args: ", join( ", ", keys %$argv ), ".";
   }

   # Testmode
   if ( $self->{host} eq "." ) {
      $self->{host} = "127.0.0.1";
      $self->_start_test_server();
   }

   my $service = $self->{service};
   my $args    = \@_;                # last arguments in the args list

   my $response;

   # first the module itself
   $response = $self->_send_request(
      {  method    => "use $service",
         wantarray => wantarray(),
      }
   );
   {
      no warnings 'uninitialized';
      die sprintf "EVAL %s@%s:%s\n%s", $self->{host},
          $response->body()->cwd(), $response->body()->eval_error()
          if $response->body()->eval_error();
   }

   # the session id we get with the first response, it should be used to
   # identify the persistent session on the remote side!
   $self->{sid} = $response->body()->sid();

   #-$self->_connection()->close();

   ### sid in request: $self->{sid}

   $response = $self->_send_request(
      {  method    => "new $service",
         sid       => $self->{sid},
         argv      => $args,
         wantarray => wantarray(),
      }
   );

   die sprintf "EVAL %s@%s:%s\n%s", $response->body()->user(), $self->{host},
       $response->body()->cwd(), $response->body()->eval_error()
       if $response->body()->eval_error();

   #-$self->_connection()->close();

   #lock_keys(%$self);
   return $self;
}

sub _send_request {
   my( $self, $params ) = @_;

   my $response;
   require OASIS::Serializer::JSON;
   OASIS::Message::request->new({
      %$params,
      serializer => OASIS::Serializer::JSON->new,
   })->write( $self->_connection() );


   use IO::Select;
   my $select = IO::Select->new();
   $select->add($self->{socket});
   unless( $select->can_read( $self->{timeout} ) ) {
      die sprintf("timeout of %s s while executing %s on %s",$self->{timeout},$self->{service},$self->{host});
   }

   $response = eval { OASIS::Message::response->new({ stream => $self->_connection() }) };
   if ( my $err = $@ ){
      die "Error occured while getting response from servers via ".$self->{host}.
         ". Please check connectivity and server configuration. Error details: $err";
   }

   # case when there is no error getting the response but the response is undefined because of whatever
   die "Unable to get response from servers via ".$self->{host}.
      ". Please check connectivity and server configuration." unless $response;

   return $response;
}

# der gilt nur im Parent (Client), damit er all die Methoden
# implentieren kann, von denen die andere Seite behauptet, sie wären
# vorhanden
# my

sub AUTOLOAD {
   my $self = shift;
   our $AUTOLOAD;
   use Data::Dumper;
   confess Dumper( $self ) unless $self->{service};
   ( my $method = $AUTOLOAD ) =~ s/^.*(?=::)/$self->{service}/;

   my $response = $self->_send_request(
      {  method    => $method,
         sid       => $self->{sid},
         argv      => \@_,
         wantarray => wantarray(),
      }
   );
   logger( DEBUG, "request written" );

   my $r = $response->body();

   #-$self->_connection()->close();

   my $error   = $r->eval_error()  if $r->eval_error();
   $!          = $r->os_error()    if $r->os_error();
   $?          = $r->child_error() if $r->child_error();

   croak "eval error: $error" if $error;
   return wantarray()
       ? @{ $response->body()->retval() }
       : $response->body()->retval();

}

sub DESTROY {
   my $self = shift;

   if ( $self->{test_server_pid} ) {
      kill "TERM", $self->{test_server_pid};
      wait;
   }
}

sub _connection {
   my $self = shift;
   {
       #########################################################
       # Just return the connection if we are already connected
       # #######################################################
       local $^W = 0;
       if( $self->{socket} ){
          if( $self->{socket}->connected() ){
            return $self->{socket}
          }{
            #we cant just reconnect here since the stete on the server seide will be lost
            #if the connection is flagged as statelest(restfull ina way ) than this could be done here but this is not
            #implemented atm
            die "oasis socket is no longer connected to ".$self->{host};
          }
       }
   }
   ####################################################################
   #Strategy pattern to try oasis protocoll version "oasis3"
   #####################################################################
   my $protocoll_strategy_hash = $self->_get_connection_protocolls();
   my $protocoll_error;
   for my $protocoll_version ( reverse( sort { $a cmp $b } keys %$protocoll_strategy_hash ) ) {
      my $protocoll_string = $protocoll_strategy_hash->{$protocoll_version}->{protocoll_string};
      my $upgrade_strategy = $protocoll_strategy_hash->{$protocoll_version}->{upgrade};

      my $ok_socket = eval {
         local $SIG{__DIE__} = 'DEFAULT';
         ##############################################################################
         #Connect to the Proxy Server if hostname consists of a "|" separated string
         ##############################################################################
         my ( $next_hop, @hosts ) = map { $_ .= /:/ ? "" : ":$self->{default_port}" }
             split /\s*\|\s*/, $self->{host};
         logger( DEBUG, "(re)connect with $protocoll_version to $next_hop" );

         $self->{socket} = IO::Socket::INET->new( PeerAddr => $next_hop, Timeout => $self->{connect_timeout})
             or croak "Can't connect to $next_hop: $!\n";
         $self->{socket}->autoflush(1);

         use Socket;
         setsockopt( $self->{socket}, SOL_SOCKET, SO_KEEPALIVE, 1);

         if (@hosts) {
            my $host_chain = join('|', @hosts );

            logger( DEBUG, "proxy forward request from $next_hop to $host_chain" );
            print { $self->{socket} } "OASIS CONNECT $host_chain\n";
            logger( DEBUG, "waiting for proxy connection");
            use IO::Select;
            my $select = IO::Select->new();
            $select->add($self->{socket});
            unless( $select->can_read( $self->{connect_timeout} ) ) {
               die "oasis connection timeout between $next_hop and $host_chain"
            }
            my $first_line = $self->{socket}->getline();

            die "connection lost between $next_hop and $host_chain" if not defined $first_line;
            $first_line =~ /^OASIS CONNECTED\s*/ or croak "proxy connection failed ($first_line)";
         }
         ##################################################
         # actual connection to server takes place here
         ##################################################
         logger( DEBUG, "TLS connection" );
         print { $self->{socket} } $protocoll_string;
         logger( DEBUG, "waiting for OASIS GO AHEAD message" );
         my $go_ahead = $self->{socket}->getline;
         $go_ahead =~  s/\s*$//;    # trim

         croak "No GO AHEAD after SSL upgrade. Abort. $go_ahead"
             if not defined $go_ahead
                or not $go_ahead eq "OASIS GO AHEAD";

         logger( DEBUG, "starting ssl upgrade" );
         $self->{socket} = $upgrade_strategy->();
         croak "No socket connection anymore: $!" if not $self->{socket};
         logger( DEBUG, "ssl should be set up" );

         $self->{socket}->timeout( $self->{timeout} );

         #print "connected with prtocoll " . $protocoll_version . "\n";
         return $self->{socket};    # will only return from the eval
      };
	   die $@ if $@ =~ /fopen/;
      $protocoll_error = $@;
      return $ok_socket if $ok_socket;
   }
   die $protocoll_error;
}

sub _get_connection_protocolls {
   my $self       = shift;

   # CIEA-4114
   # we want to restrict to TLS 1.2 and higher but some servers do only support up to TLS 1.0
   # as a temporary oslution we create a oasis-ng papckage that restricts the oasis3.pm (server)
   # to TLS 1.2. It is only installed if supported by the os, thus for OASIS.pm (client) we still
   # need to allow TLS 1.0 and TLS 1.1 to be able to reach old servers even if the client
   # supports higher TLS versions. Over the time, all servers will be patched and we can close
   # the gap between client and server. Anyhow, client and server will always agree on the highest
   # version available for both
   my $s_ssl_version = 'SSLv23:!SSLv3:!SSLv2';

   my $protocolls = {
      'oasis3' => {
         protocoll_string => "START TLS OASIS/3\n",
         upgrade          => sub {
			croak "fopen file not found ".$self->{certfile} unless -f $self->{certfile};
			croak "fopen file not found ".$self->{keyfile} unless -f $self->{keyfile};
			croak "fopen file not found ".$self->{ca_file} unless -f $self->{ca_file};
            $self->{socket} = IO::Socket::SSL->start_SSL(
               $self->{socket},
               SSL_cert_file => $self->{certfile},
               SSL_key_file  => $self->{keyfile},
               SSL_ca_file   => $self->{ca_file},
               SSL_use_cert  => 1,
               SSL_version   => $s_ssl_version,
	       SSL_verify_mode => SSL_VERIFY_NONE,
            ) or die "SSL Upgrade failed: " . &IO::Socket::SSL::errstr();
             }
      },

   };
}

1;
__DATA__

=head1 NAME

oasis -- the client side module

=head1 SYNOPSIS

   use OASIS;

   my $service = new OASIS({ service => "demo" }, qw(:all));

   my $service = new OASIS({ service => "demo" },
	 host => ".", qw(:all));

   my $service = new OASIS({ service => "demo",
	 host => "hostC", port => "8086" }, qw(:all));

   my $service = new OASIS({ service => "demo",
	 host => "hostA|hostB:8888|hostC", port => "8086" }, qw(:all));

   $x = $service->greeting("Kurt");
   @y = $service->get_items();

=head1 DESCRIPTION

The B<OASIS> class is the main client side visible part of the OASIS
framework.  It hides all the details of the RPC and connection handling
to the OASIS server(s).

Local connections (target host is B<localhost> or B<127.X.X.X>) are
handled as plain text (no SSL setup).  For everything else SSL is used.

=head1 CONSTRUCTOR

=over

=item new(I<OPTIONS> [,I<PARAMS>]])

Create a new OASIS object (connected to some OASIS server).

C<OPTIONS> are mandatory and passed as a hash reference. C<PARAMS> are
passed verbatim to the contructor of the loaded service (module).

The following options are recognised in the C<OPTIONS> hash reference:

=over

=item B<service>=I<service>

This is the name of the module to be loaded on the server side.
(mandatory, alias: use)

=item B<host>=I<hostname>[:I<port>]

Host to connect to.  If the host is a single dot (B<.>), we switch to
testmode and fork a local connected server. (optional, default: localhost)
B<NOTE:> The testserver uses the F<oasis.conf> found in the current
directory, nothing else!

=item B<host>=I<hostA>[:I<port>]|I<hostB>[:I<port>]...

Host to connect to, but as chain of proxy servers.

=item B<port>=I<port>

B<Default port> to connect to (note: this parameter gets B<overridden> by
the port given with the hostname. (optional, default: 8086)

=item B<tls>=[I<true>|I<false>]

If I<true> TLS is forced, even on connections to localhost.

=item B<conf>=...

=back

=back

=head1 METHODS

=over

=item AUTOLOAD

All unknown methods are passed to the remote side (this is done via the
local C<AUTOLOAD> mechanism.  Along with the functions arguments the RPC
call passes information about the calling context (C<wantarray>).

=back

=head1 FILES

If used with the test server (Hostname ".") the found in callers
working directory is used. This you may override using the environment
C<OASIS_TEST_CONF>.

=head1 STATUS

=over

=item API: stable

=item Doc: stable

=back

=head1 AUTHORS

Marcus Obst <mobst@schlittermann.de> and Heiko Schlittermann
<hs@schlittermann.de>

=head1 TODO

The API shoule be extended to pass options to the C<use SERVICE> on the
remote side.

=cut
